package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

/** Estatística descritiva e séries temporais. */
@Service
public class EstatisticaService {

    private final Reservatorio reservatorio;

    public EstatisticaService(Reservatorio reservatorio) {
        this.reservatorio = reservatorio;
    }

    public Dtos.ResumoDTO resumo(List<Leitura> leituras) {
        int metalicas = 0, naoMetalicas = 0, conflitos = 0, invalidas = 0;
        DescriptiveStatistics nivel = new DescriptiveStatistics();
        Double nivelAtual = null;

        for (Leitura l : leituras) {
            if (l.isIndutivo() && l.isCapacitivo()) conflitos++;
            else if (l.isIndutivo()) metalicas++;
            else if (l.isCapacitivo()) naoMetalicas++;

            if (reservatorio.valida(l.getDistanciaCm())) {
                double pct = reservatorio.pct(l.getDistanciaCm());
                nivel.addValue(pct);
                nivelAtual = pct; // lista ordenada: a última válida é a atual
            } else {
                invalidas++;
            }
        }

        int total = metalicas + naoMetalicas + conflitos;
        int classificadas = metalicas + naoMetalicas;
        double minutos = duracaoMinutos(leituras);
        boolean temNivel = nivel.getN() > 0;

        return new Dtos.ResumoDTO(
                leituras.size(), total, metalicas, naoMetalicas, conflitos,
                classificadas > 0 ? Reservatorio.arred(metalicas * 100.0 / classificadas) : 0,
                classificadas > 0 ? Reservatorio.arred(naoMetalicas * 100.0 / classificadas) : 0,
                nivelAtual == null ? null : Reservatorio.arred(nivelAtual),
                temNivel ? Reservatorio.arred(nivel.getMean()) : null,
                temNivel ? Reservatorio.arred(nivel.getPercentile(50)) : null,
                temNivel ? Reservatorio.arred(nivel.getStandardDeviation()) : null,
                temNivel ? Reservatorio.arred(nivel.getMin()) : null,
                temNivel ? Reservatorio.arred(nivel.getMax()) : null,
                minutos > 0 ? Reservatorio.arred(total / minutos) : 0,
                invalidas,
                status(nivelAtual));
    }

    /** Agrega as leituras em janelas de N minutos e calcula média móvel do nível. */
    public List<Dtos.PontoSerieDTO> serie(List<Leitura> leituras, int intervaloMin, int janela) {
        long passo = Math.max(1, intervaloMin) * 60L;
        int w = Math.max(1, janela);

        Map<Long, List<Leitura>> grupos = leituras.stream().collect(Collectors.groupingBy(
                l -> l.getTimestamp().toEpochSecond(ZoneOffset.UTC) / passo,
                TreeMap::new, Collectors.toList()));

        List<Dtos.PontoSerieDTO> pontos = new ArrayList<>();
        List<Double> niveisMedios = new ArrayList<>();

        for (Map.Entry<Long, List<Leitura>> e : grupos.entrySet()) {
            int met = 0, nao = 0, conf = 0;
            DescriptiveStatistics ds = new DescriptiveStatistics();
            for (Leitura l : e.getValue()) {
                if (l.isIndutivo() && l.isCapacitivo()) conf++;
                else if (l.isIndutivo()) met++;
                else if (l.isCapacitivo()) nao++;
                if (reservatorio.valida(l.getDistanciaCm())) ds.addValue(reservatorio.pct(l.getDistanciaCm()));
            }
            Double medio = ds.getN() > 0 ? Reservatorio.arred(ds.getMean()) : null;
            niveisMedios.add(medio);

            pontos.add(new Dtos.PontoSerieDTO(
                    LocalDateTime.ofEpochSecond(e.getKey() * passo, 0, ZoneOffset.UTC),
                    met + nao + conf, met, nao, medio, mediaMovel(niveisMedios, w)));
        }
        return pontos;
    }

    private Double mediaMovel(List<Double> valores, int janela) {
        double soma = 0;
        int n = 0;
        for (int j = Math.max(0, valores.size() - janela); j < valores.size(); j++) {
            Double v = valores.get(j);
            if (v != null) { soma += v; n++; }
        }
        return n > 0 ? Reservatorio.arred(soma / n) : null;
    }

    private double duracaoMinutos(List<Leitura> leituras) {
        if (leituras.size() < 2) return 0;
        Duration d = Duration.between(leituras.get(0).getTimestamp(),
                leituras.get(leituras.size() - 1).getTimestamp());
        return d.getSeconds() / 60.0;
    }

    private String status(Double nivelAtual) {
        if (nivelAtual == null) return "SEM_DADOS";
        if (nivelAtual >= reservatorio.getLimiteAlertaPct()) return "ALERTA";
        if (nivelAtual >= reservatorio.getLimiteAtencaoPct()) return "ATENCAO";
        return "NORMAL";
    }
}

package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos.AnomaliaDTO;
import br.com.metaltech.monitoramento.model.Leitura;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Regras de detecção de anomalias (as mesmas que você justifica no parecer técnico). */
@Service
public class AnomaliaService {

    private final Reservatorio reservatorio;
    private final double zLimite;
    private final int travadoMin;
    private final int paradaMin;

    public AnomaliaService(
            Reservatorio reservatorio,
            @Value("${metaltech.anomalias.z-limite:3.0}") double zLimite,
            @Value("${metaltech.anomalias.sensor-travado-min-leituras:15}") int travadoMin,
            @Value("${metaltech.anomalias.esteira-parada-min-leituras:30}") int paradaMin) {
        this.reservatorio = reservatorio;
        this.zLimite = zLimite;
        this.travadoMin = travadoMin;
        this.paradaMin = paradaMin;
    }

    /** Recebe leituras ordenadas por tempo. */
    public List<AnomaliaDTO> detectar(List<Leitura> leituras) {
        List<AnomaliaDTO> res = new ArrayList<>();
        regrasPorLeitura(leituras, res);
        saltosBruscos(leituras, res);
        sensorTravado(leituras, res);
        esteiraParada(leituras, res);
        nivelCritico(leituras, res);
        res.sort(Comparator.comparing(AnomaliaDTO::timestamp));
        return res;
    }

    // 1) Leitura ausente, impossível ou sensores em conflito
    private void regrasPorLeitura(List<Leitura> leituras, List<AnomaliaDTO> res) {
        for (Leitura l : leituras) {
            Double d = l.getDistanciaCm();
            if (d == null) {
                res.add(new AnomaliaDTO(l.getTimestamp(), "LEITURA_AUSENTE", "MEDIA",
                        "Sensor de distância sem leitura", null));
            } else if (!reservatorio.valida(d)) {
                res.add(new AnomaliaDTO(l.getTimestamp(), "LEITURA_INVALIDA", "ALTA",
                        "Distância fora da faixa física (0 a " + reservatorio.getAlturaCm() + " cm)", d));
            }
            if (l.isIndutivo() && l.isCapacitivo()) {
                res.add(new AnomaliaDTO(l.getTimestamp(), "CONFLITO_SENSORES", "MEDIA",
                        "Indutivo e capacitivo ativos ao mesmo tempo", null));
            }
        }
    }

    // 2) Salto brusco: z-score da variação (delta) do nível entre leituras consecutivas.
    //    Esvaziamentos do reservatório são eventos normais e ficam fora da estatística.
    private void saltosBruscos(List<Leitura> leituras, List<AnomaliaDTO> res) {
        List<Leitura> validas = reservatorio.validas(leituras);
        List<Delta> deltas = new ArrayList<>();
        DescriptiveStatistics stats = new DescriptiveStatistics();

        for (int i = 1; i < validas.size(); i++) {
            double anterior = reservatorio.pct(validas.get(i - 1).getDistanciaCm());
            double atual = reservatorio.pct(validas.get(i).getDistanciaCm());
            if (reservatorio.esvaziamento(anterior, atual)) continue;
            double variacao = atual - anterior;
            deltas.add(new Delta(validas.get(i), variacao));
            stats.addValue(variacao);
        }
        if (deltas.size() < 10) return;

        double media = stats.getMean();
        double dp = stats.getStandardDeviation();
        if (dp == 0) return;

        for (Delta dl : deltas) {
            double z = (dl.variacao() - media) / dp;
            if (Math.abs(z) > zLimite) {
                res.add(new AnomaliaDTO(dl.leitura().getTimestamp(), "SALTO_BRUSCO", "MEDIA",
                        String.format(Locale.US, "Variação de %.1f p.p. entre leituras (z = %.1f)",
                                dl.variacao(), z),
                        Reservatorio.arred(dl.variacao())));
            }
        }
    }

    // 3) Sensor travado: mesma distância repetida por N leituras seguidas
    private void sensorTravado(List<Leitura> leituras, List<AnomaliaDTO> res) {
        Double valorRun = null;
        int run = 0;
        Leitura inicio = null;
        for (Leitura l : leituras) {
            Double d = l.getDistanciaCm();
            if (!reservatorio.valida(d)) { run = 0; valorRun = null; continue; }
            if (valorRun != null && Double.compare(valorRun, d) == 0) {
                run++;
            } else {
                valorRun = d;
                run = 1;
                inicio = l;
            }
            if (run == travadoMin) { // avisa uma única vez por sequência
                res.add(new AnomaliaDTO(inicio.getTimestamp(), "SENSOR_TRAVADO", "ALTA",
                        "Distância repetida em " + travadoMin + "+ leituras seguidas", d));
            }
        }
    }

    // 4) Esteira parada: nenhuma peça detectada por N leituras seguidas
    private void esteiraParada(List<Leitura> leituras, List<AnomaliaDTO> res) {
        int run = 0;
        Leitura inicio = null;
        for (Leitura l : leituras) {
            if (!l.isIndutivo() && !l.isCapacitivo()) {
                if (run == 0) inicio = l;
                run++;
                if (run == paradaMin) {
                    res.add(new AnomaliaDTO(inicio.getTimestamp(), "ESTEIRA_PARADA", "ALTA",
                            "Nenhuma peça detectada em " + paradaMin + "+ leituras seguidas", null));
                }
            } else {
                run = 0;
            }
        }
    }

    // 5) Reservatório cruzou o limite de alerta (avisa só no momento em que cruza)
    private void nivelCritico(List<Leitura> leituras, List<AnomaliaDTO> res) {
        double anterior = 0;
        for (Leitura l : reservatorio.validas(leituras)) {
            double atual = reservatorio.pct(l.getDistanciaCm());
            if (anterior < reservatorio.getLimiteAlertaPct() && atual >= reservatorio.getLimiteAlertaPct()) {
                res.add(new AnomaliaDTO(l.getTimestamp(), "NIVEL_CRITICO", "ALTA",
                        "Reservatório atingiu " + Reservatorio.arred(atual) + "%", Reservatorio.arred(atual)));
            }
            anterior = atual;
        }
    }

    private record Delta(Leitura leitura, double variacao) {}
}

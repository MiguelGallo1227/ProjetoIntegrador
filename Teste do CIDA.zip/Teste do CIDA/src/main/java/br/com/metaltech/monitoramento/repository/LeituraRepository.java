package br.com.metaltech.monitoramento.repository;

import br.com.metaltech.monitoramento.model.Leitura;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface LeituraRepository extends JpaRepository<Leitura, Long> {

    List<Leitura> findAllByOrderByTimestampAsc();

    List<Leitura> findByTimestampBetweenOrderByTimestampAsc(LocalDateTime inicio, LocalDateTime fim);
}

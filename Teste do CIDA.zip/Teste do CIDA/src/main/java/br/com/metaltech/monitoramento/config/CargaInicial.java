package br.com.metaltech.monitoramento.config;

import br.com.metaltech.monitoramento.service.SimuladorService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Popula o banco com leituras simuladas na inicialização. */
@Component
public class CargaInicial implements CommandLineRunner {

    private final SimuladorService simulador;
    private final boolean aoIniciar;

    public CargaInicial(SimuladorService simulador,
                        @Value("${metaltech.simulador.ao-iniciar:true}") boolean aoIniciar) {
        this.simulador = simulador;
        this.aoIniciar = aoIniciar;
    }

    @Override
    public void run(String... args) {
        if (aoIniciar) {
            int n = simulador.gerarESalvar(2000, 42L, 10);
            System.out.println("[MetalTech] " + n + " leituras simuladas geradas.");
        }
    }
}

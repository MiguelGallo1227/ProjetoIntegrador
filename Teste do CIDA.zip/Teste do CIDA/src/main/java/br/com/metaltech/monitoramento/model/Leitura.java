package br.com.metaltech.monitoramento.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Uma leitura da esteira (um "tick" dos sensores).
 * distanciaCm: sensor de distância no topo do reservatório (menor distância = mais cheio).
 * indutivo: detectou peça metálica. capacitivo: detectou peça não metálica.
 */
@Entity
@Table(name = "leituras", indexes = @Index(name = "idx_leitura_data_hora", columnList = "data_hora"))
public class Leitura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "data_hora", nullable = false)
    private LocalDateTime timestamp;

    @Column(name = "distancia_cm")
    private Double distanciaCm; // pode ser null (falha do sensor)

    private boolean indutivo;
    private boolean capacitivo;

    @Column(name = "contador_total")
    private int contadorTotal;

    public Leitura() {}

    public Leitura(LocalDateTime timestamp, Double distanciaCm, boolean indutivo,
                   boolean capacitivo, int contadorTotal) {
        this.timestamp = timestamp;
        this.distanciaCm = distanciaCm;
        this.indutivo = indutivo;
        this.capacitivo = capacitivo;
        this.contadorTotal = contadorTotal;
    }

    public Long getId() { return id; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public Double getDistanciaCm() { return distanciaCm; }
    public void setDistanciaCm(Double distanciaCm) { this.distanciaCm = distanciaCm; }
    public boolean isIndutivo() { return indutivo; }
    public void setIndutivo(boolean indutivo) { this.indutivo = indutivo; }
    public boolean isCapacitivo() { return capacitivo; }
    public void setCapacitivo(boolean capacitivo) { this.capacitivo = capacitivo; }
    public int getContadorTotal() { return contadorTotal; }
    public void setContadorTotal(int contadorTotal) { this.contadorTotal = contadorTotal; }
}

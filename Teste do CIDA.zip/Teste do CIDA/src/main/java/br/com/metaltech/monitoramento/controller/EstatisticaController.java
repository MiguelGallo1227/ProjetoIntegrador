package br.com.metaltech.monitoramento.controller;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.service.AnomaliaService;
import br.com.metaltech.monitoramento.service.EstatisticaService;
import br.com.metaltech.monitoramento.service.LeituraService;
import br.com.metaltech.monitoramento.service.PrevisaoService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

/** Endpoints da Ciência de Dados. Todos aceitam ?inicio=...&fim=... (ISO, ex.: 2026-11-10T08:00:00). */
@RestController
@RequestMapping("/api/estatisticas")
public class EstatisticaController {

    private final LeituraService leituras;
    private final EstatisticaService estatistica;
    private final AnomaliaService anomalias;
    private final PrevisaoService previsao;

    public EstatisticaController(LeituraService leituras, EstatisticaService estatistica,
                                 AnomaliaService anomalias, PrevisaoService previsao) {
        this.leituras = leituras;
        this.estatistica = estatistica;
        this.anomalias = anomalias;
        this.previsao = previsao;
    }

    @GetMapping("/resumo")
    public Dtos.ResumoDTO resumo(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fim) {
        return estatistica.resumo(leituras.buscar(inicio, fim));
    }

    @GetMapping("/serie")
    public List<Dtos.PontoSerieDTO> serie(
            @RequestParam(defaultValue = "5") int intervaloMin,
            @RequestParam(defaultValue = "3") int janela,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fim) {
        return estatistica.serie(leituras.buscar(inicio, fim), intervaloMin, janela);
    }

    @GetMapping("/anomalias")
    public List<Dtos.AnomaliaDTO> anomalias(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fim) {
        return anomalias.detectar(leituras.buscar(inicio, fim));
    }

    @GetMapping("/previsao-enchimento")
    public Dtos.PrevisaoDTO previsao(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fim) {
        return previsao.prever(leituras.buscar(inicio, fim));
    }
}

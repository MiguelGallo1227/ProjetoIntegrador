package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import br.com.metaltech.monitoramento.repository.LeituraRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LeituraService {

    private final LeituraRepository repo;

    public LeituraService(LeituraRepository repo) {
        this.repo = repo;
    }

    /** Leituras em ordem cronológica; inicio/fim são opcionais. */
    public List<Leitura> buscar(LocalDateTime inicio, LocalDateTime fim) {
        if (inicio == null && fim == null) return repo.findAllByOrderByTimestampAsc();
        LocalDateTime i = inicio != null ? inicio : LocalDateTime.of(2000, 1, 1, 0, 0);
        LocalDateTime f = fim != null ? fim : LocalDateTime.of(2100, 1, 1, 0, 0);
        return repo.findByTimestampBetweenOrderByTimestampAsc(i, f);
    }

    /** As N leituras mais recentes (mais nova primeiro). */
    public List<Leitura> ultimas(int limite) {
        return repo.findAll(PageRequest.of(0, Math.max(1, limite), Sort.by(Sort.Direction.DESC, "timestamp")))
                .getContent();
    }

    public Leitura registrar(Dtos.LeituraRequest req) {
        LocalDateTime ts = req.timestamp() != null ? req.timestamp() : LocalDateTime.now();
        int contador;
        if (req.contadorTotal() != null) {
            contador = req.contadorTotal();
        } else {
            List<Leitura> ult = ultimas(1);
            int base = ult.isEmpty() ? 0 : ult.get(0).getContadorTotal();
            contador = base + ((req.indutivo() || req.capacitivo()) ? 1 : 0);
        }
        return repo.save(new Leitura(ts, req.distanciaCm(), req.indutivo(), req.capacitivo(), contador));
    }

    public String exportarCsv(List<Leitura> leituras) {
        StringBuilder sb = new StringBuilder("timestamp,distancia_cm,indutivo,capacitivo,contador_total\n");
        for (Leitura l : leituras) {
            sb.append(l.getTimestamp()).append(',')
              .append(l.getDistanciaCm() == null ? "" : l.getDistanciaCm()).append(',')
              .append(l.isIndutivo() ? 1 : 0).append(',')
              .append(l.isCapacitivo() ? 1 : 0).append(',')
              .append(l.getContadorTotal()).append('\n');
        }
        return sb.toString();
    }
}

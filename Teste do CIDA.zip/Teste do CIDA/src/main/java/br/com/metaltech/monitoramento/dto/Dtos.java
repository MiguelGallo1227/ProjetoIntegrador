package br.com.metaltech.monitoramento.dto;

import java.time.LocalDateTime;

/** Contratos JSON da API (o que o React e o app de RA vão consumir). */
public final class Dtos {

    private Dtos() {}

    public record ResumoDTO(
            int totalLeituras,
            int totalPecas,
            int metalicas,
            int naoMetalicas,
            int conflitosSensores,
            double pctMetalicas,          // sobre as peças classificadas (sem conflito)
            double pctNaoMetalicas,
            Double nivelAtualPct,
            Double nivelMediaPct,
            Double nivelMedianaPct,
            Double nivelDesvioPct,
            Double nivelMinPct,
            Double nivelMaxPct,
            double pecasPorMinuto,
            int leiturasInvalidas,
            String status) {}             // NORMAL | ATENCAO | ALERTA | SEM_DADOS

    public record PontoSerieDTO(
            LocalDateTime inicio,
            int pecas,
            int metalicas,
            int naoMetalicas,
            Double nivelMedioPct,
            Double mediaMovelNivelPct) {}

    public record AnomaliaDTO(
            LocalDateTime timestamp,
            String tipo,
            String severidade,            // BAIXA | MEDIA | ALTA
            String descricao,
            Double valor) {}

    public record PrevisaoDTO(
            String status,                // OK | SEM_TENDENCIA | DADOS_INSUFICIENTES
            int amostras,
            Double nivelAtualPct,
            Double taxaPctPorMinuto,
            Double minutosAte90,
            Double minutosAte100,
            LocalDateTime previsaoEnchimento,
            Double r2,
            Double correlacaoContagemNivel) {}

    /** Corpo do POST /api/leituras (para o CLP/sensor real enviar dados). */
    public record LeituraRequest(
            LocalDateTime timestamp,      // opcional (padrão: agora)
            Double distanciaCm,
            boolean indutivo,
            boolean capacitivo,
            Integer contadorTotal) {}     // opcional (padrão: último + 1 se houve peça)
}

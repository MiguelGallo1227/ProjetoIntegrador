package br.com.metaltech.monitoramento.controller;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import br.com.metaltech.monitoramento.service.LeituraService;
import br.com.metaltech.monitoramento.service.SimuladorService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/** Entrada de dados (sensor/CLP real ou simulador) e exportação para o relatório. */
@RestController
@RequestMapping("/api")
public class LeituraController {

    private final LeituraService leituras;
    private final SimuladorService simulador;

    public LeituraController(LeituraService leituras, SimuladorService simulador) {
        this.leituras = leituras;
        this.simulador = simulador;
    }

    /** O CLP/ESP32/Node-RED envia cada leitura aqui. */
    @PostMapping("/leituras")
    public Leitura registrar(@RequestBody Dtos.LeituraRequest req) {
        return leituras.registrar(req);
    }

    @GetMapping("/leituras")
    public List<Leitura> ultimas(@RequestParam(defaultValue = "100") int limite) {
        return leituras.ultimas(Math.min(limite, 1000));
    }

    /** CSV para abrir no Excel / Jupyter / usar como evidência no parecer. */
    @GetMapping("/leituras/export")
    public ResponseEntity<String> exportar(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fim) {
        String csv = leituras.exportarCsv(leituras.buscar(inicio, fim));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=leituras.csv")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csv);
    }

    /** Apaga as leituras e gera uma base simulada nova. */
    @PostMapping("/simulador")
    public Map<String, Integer> simular(
            @RequestParam(defaultValue = "2000") int quantidade,
            @RequestParam(defaultValue = "42") long seed,
            @RequestParam(defaultValue = "10") int intervaloSeg) {
        if (quantidade < 200 || quantidade > 50_000) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "quantidade deve estar entre 200 e 50000");
        }
        return Map.of("leiturasGeradas", simulador.gerarESalvar(quantidade, seed, intervaloSeg));
    }
}

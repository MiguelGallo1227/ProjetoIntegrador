package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.ZoneOffset;
import java.util.List;

/** Regressão linear do nível em função do tempo: em quanto tempo o reservatório enche? */
@Service
public class PrevisaoService {

    private final Reservatorio reservatorio;
    private final int minAmostras;

    public PrevisaoService(Reservatorio reservatorio,
                           @Value("${metaltech.previsao.min-amostras:10}") int minAmostras) {
        this.reservatorio = reservatorio;
        this.minAmostras = minAmostras;
    }

    public Dtos.PrevisaoDTO prever(List<Leitura> leituras) {
        List<Leitura> ciclo = reservatorio.cicloAtual(reservatorio.validas(leituras));
        int n = ciclo.size();
        if (n < minAmostras) {
            return new Dtos.PrevisaoDTO("DADOS_INSUFICIENTES", n, null, null, null, null, null, null, null);
        }

        long t0 = ciclo.get(0).getTimestamp().toEpochSecond(ZoneOffset.UTC);
        double[] x = new double[n];
        double[] y = new double[n];
        double[] contagem = new double[n];
        for (int i = 0; i < n; i++) {
            Leitura l = ciclo.get(i);
            x[i] = l.getTimestamp().toEpochSecond(ZoneOffset.UTC) - t0; // segundos desde o início do ciclo
            y[i] = reservatorio.pct(l.getDistanciaCm());
            contagem[i] = l.getContadorTotal();
        }

        // 1ª passada: ajuste com tudo, para achar pontos muito fora da reta
        SimpleRegression primeira = new SimpleRegression();
        for (int i = 0; i < n; i++) primeira.addData(x[i], y[i]);
        double[] residuos = new double[n];
        DescriptiveStatistics ds = new DescriptiveStatistics();
        for (int i = 0; i < n; i++) {
            residuos[i] = y[i] - primeira.predict(x[i]);
            ds.addValue(residuos[i]);
        }
        double sd = ds.getStandardDeviation();
        double limite = sd < 1e-9 ? Double.MAX_VALUE : 2.5 * sd;

        // 2ª passada: ajuste final sem os outliers
        SimpleRegression reg = new SimpleRegression();
        int usadas = 0;
        for (int i = 0; i < n; i++) {
            if (Math.abs(residuos[i]) <= limite) { reg.addData(x[i], y[i]); usadas++; }
        }

        double inclinacao = reg.getSlope(); // p.p. por segundo
        if (usadas < 3 || Double.isNaN(inclinacao) || inclinacao <= 0) {
            return new Dtos.PrevisaoDTO("SEM_TENDENCIA", n, null, null, null, null, null, null, null);
        }

        double nivelAtual = Math.max(0, Math.min(100, reg.predict(x[n - 1])));
        double taxaPorMin = inclinacao * 60.0;
        double min90 = nivelAtual >= 90 ? 0 : (90 - nivelAtual) / taxaPorMin;
        double min100 = nivelAtual >= 100 ? 0 : (100 - nivelAtual) / taxaPorMin;

        double corr = new PearsonsCorrelation().correlation(contagem, y);

        return new Dtos.PrevisaoDTO(
                "OK", n,
                Reservatorio.arred(nivelAtual),
                Reservatorio.arred(taxaPorMin),
                Reservatorio.arred(min90),
                Reservatorio.arred(min100),
                ciclo.get(n - 1).getTimestamp().plusSeconds(Math.round(min100 * 60)),
                Reservatorio.arred(reg.getRSquare()),
                Double.isNaN(corr) ? null : Reservatorio.arred(corr));
    }
}

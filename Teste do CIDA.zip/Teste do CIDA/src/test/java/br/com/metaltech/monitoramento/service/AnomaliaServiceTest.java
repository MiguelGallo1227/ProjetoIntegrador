package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertTrue;

class AnomaliaServiceTest {

    @Test
    void detectaFalhasInjetadasNaBaseSimulada() {
        Reservatorio r = new Reservatorio(30, 75, 90);
        SimuladorService sim = new SimuladorService(null, r); // sem banco: só gerarLista()
        List<Leitura> ls = sim.gerarLista(2000, 42L, 10, LocalDateTime.of(2026, 11, 10, 0, 0));

        AnomaliaService servico = new AnomaliaService(r, 3.0, 15, 30);
        Set<String> tipos = servico.detectar(ls).stream()
                .map(Dtos.AnomaliaDTO::tipo)
                .collect(Collectors.toSet());

        assertTrue(tipos.containsAll(Set.of("ESTEIRA_PARADA", "SENSOR_TRAVADO", "CONFLITO_SENSORES")),
                "tipos encontrados: " + tipos);
    }
}

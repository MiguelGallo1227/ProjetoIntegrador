package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PrevisaoServiceTest {

    @Test
    void regressaoLinearEstimaTempoAteEncher() {
        Reservatorio r = new Reservatorio(30, 75, 90);
        PrevisaoService servico = new PrevisaoService(r, 10);

        // nível sobe exatamente 1 p.p. por minuto, de 10% até ~19,8% (60 leituras de 10 s)
        List<Leitura> ls = new ArrayList<>();
        LocalDateTime t0 = LocalDateTime.of(2026, 11, 10, 8, 0);
        for (int i = 0; i < 60; i++) {
            double pct = 10 + i * (10.0 / 60);
            double dist = 30 * (1 - pct / 100);
            ls.add(new Leitura(t0.plusSeconds(i * 10L), dist, i % 3 == 0, i % 3 == 1, i));
        }

        Dtos.PrevisaoDTO p = servico.prever(ls);

        assertEquals("OK", p.status());
        assertEquals(1.0, p.taxaPctPorMinuto(), 0.05);
        assertEquals(80.2, p.minutosAte100(), 0.5);
    }
}

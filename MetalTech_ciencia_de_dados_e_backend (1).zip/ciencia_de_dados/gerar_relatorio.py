"""Monta o Relatório de Ciência de Dados (.docx) a partir de dados/resultados.json e graficos/*.png.
Rode depois de analise.py:  python3 gerar_relatorio.py"""
import json
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

AQUI = Path(__file__).parent
r = json.loads((AQUI / "dados/resultados.json").read_text(encoding="utf-8"))
df = pd.read_csv(AQUI / "dados/leituras_com_alertas.csv", parse_dates=["data_hora"])
quedas = (df.nivel_reservatorio.diff() < -50).sum()                    # esvaziamentos
ciclo_min = (df.data_hora.max() - df.data_hora.min()).total_seconds() / 60  # usado só para ordem de grandeza
intervalo = df.data_hora.diff().dt.total_seconds()
intervalo = intervalo[intervalo < 120]
v = r["validacao_criterio"]
f = lambda x, d=2: f"{x:.{d}f}".replace(".", ",")

doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
for m in ("left_margin", "right_margin"): setattr(sec, m, Cm(2.5))
sec.top_margin = sec.bottom_margin = Cm(2.2)
st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
st.paragraph_format.space_after = Pt(6); st.paragraph_format.line_spacing = 1.2
for nome, tam in (("Heading 1", 15), ("Heading 2", 12.5)):
    h = doc.styles[nome]; h.font.name = "Calibri"; h.font.size = Pt(tam); h.font.bold = True
    h.font.color.rgb = RGBColor(0x1F, 0x2A, 0x44)
    h.element.rPr.rFonts.set(qn("w:ascii"), "Calibri"); h.element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    h.paragraph_format.space_before = Pt(14); h.paragraph_format.space_after = Pt(6)
    h.paragraph_format.keep_with_next = True


def p(texto, bold=False, italic=False, align=None):
    par = doc.add_paragraph(); run = par.add_run(texto); run.bold = bold; run.italic = italic
    if align: par.alignment = align
    return par


def bullets(itens):
    for i in itens: doc.add_paragraph(i, style="List Bullet")


def shade(cell, cor):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), cor); tcPr.append(sh)


def tabela(cab, linhas, larguras):
    t = doc.add_table(rows=1, cols=len(cab)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, c in enumerate(cab):
        cell = t.rows[0].cells[i]; cell.text = ""; run = cell.paragraphs[0].add_run(c); run.bold = True
        run.font.size = Pt(10); shade(cell, "DCE3EE")
    for ln in linhas:
        cells = t.add_row().cells
        for i, c in enumerate(ln):
            cells[i].text = ""; run = cells[i].paragraphs[0].add_run(str(c)); run.font.size = Pt(10)
            if i: cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for row in t.rows:
        for i, w in enumerate(larguras): row.cells[i].width = Cm(w)
    doc.add_paragraph()


def figura(arq, legenda, larg=15.5):
    doc.add_picture(str(AQUI / "graficos" / arq), width=Cm(larg))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.paragraphs[-1].paragraph_format.keep_with_next = True
    c = p(legenda, italic=True, align=WD_ALIGN_PARAGRAPH.CENTER); c.runs[0].font.size = Pt(9.5)


# ------------------------------------------------------------------ capa
doc.add_paragraph().paragraph_format.space_before = Pt(120)
t = p("Relatório de Ciência de Dados", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER); t.runs[0].font.size = Pt(26)
t = p("Plataforma Inteligente de Monitoramento Industrial — MetalTech", align=WD_ALIGN_PARAGRAPH.CENTER); t.runs[0].font.size = Pt(14)
p("Projeto Interdisciplinar II · Análise dos dados da esteira de triagem", align=WD_ALIGN_PARAGRAPH.CENTER)
p("Autor(a): ____________________   Turma: ADS   Data: ____/____/______", align=WD_ALIGN_PARAGRAPH.CENTER)
doc.add_page_break()

# ------------------------------------------------------------------ 1
doc.add_heading("1. Objetivo e escopo", 1)
p("Este relatório apresenta o tratamento estatístico dos dados coletados pela esteira de triagem da MetalTech: "
  "contagem de peças por tipo (metálica / não metálica) e nível do reservatório de saída. O objetivo é descrever o "
  "comportamento normal da linha, identificar outliers e propor um critério simples de alerta, que foi implementado "
  "no back-end (API REST) e pode ser consumido pelo dashboard e pelo aplicativo de Realidade Aumentada.")
p("Importante: a base analisada é simulada, gerada pelo script analise.py com o mesmo formato da tabela leitura do banco "
  "(data_hora, tipo_peca, nivel_reservatorio). A situação-problema permite esse uso didático. Ao rodar o mesmo script sobre "
  "o CSV exportado do banco real, todas as tabelas e gráficos abaixo são recalculados.", italic=True)

doc.add_heading("2. Base de dados e metodologia", 1)
bullets([
    f"Período: 3 turnos de 8 h (10 a 12/11/2026), {r['total_pecas']} peças registradas — uma linha por peça classificada pelo back-end.",
    f"Intervalo médio entre peças: {f(intervalo.mean(), 1)} s. Proporção simulada: ≈ 38% metálicas e 62% não metálicas.",
    f"O nível do reservatório (0–100%) vem do sensor de distância (0% = vazio, 100% = cheio). Ele sobe a cada peça e cai "
    f"quando o operador esvazia o reservatório ({quedas} esvaziamentos no período, ao passar de ≈ 90%).",
    "Foram injetados 2 episódios de enchimento acelerado (10 leituras cada, 4 a 6 vezes a taxa normal), representando por "
    "exemplo uma saída bloqueada. Eles servem como verdade conhecida para validar o critério de alerta.",
    "Ferramentas: Python (pandas, matplotlib). Quartis por interpolação linear e desvio padrão amostral (n − 1), "
    "idênticos aos do back-end (Java) e do dashboard (JavaScript).",
])

# ------------------------------------------------------------------ 3
doc.add_heading("3. Estatística descritiva", 1)
doc.add_heading("3.1 Contagem de peças por tipo", 2)
linhas = [(d, g["total"], g["metalicas"], g["nao_metalicas"], f"{f(g['pct_metalicas'], 1)}%") for d, g in r["por_dia"].items()]
linhas.append(("Total", r["total_pecas"], r["metalicas"], r["nao_metalicas"], f"{f(r['proporcao_metalicas_pct'], 1)}%"))
tabela(["Dia", "Total", "Metálicas", "Não metálicas", "% metálicas"], linhas, [3, 3, 3.2, 3.6, 3.2])
pn = r["pecas_por_hora"]
p(f"A produção é estável: mediana de {f(pn['mediana'], 0)} peças por hora, desvio padrão de {f(pn['desvio_padrao'], 1)} "
  f"(coeficiente de variação ≈ {f(100 * pn['desvio_padrao'] / pn['media'], 1)}%). A proporção de metálicas varia entre "
  f"{f(min(g['pct_metalicas'] for g in r['por_dia'].values()), 1)}% e {f(max(g['pct_metalicas'] for g in r['por_dia'].values()), 1)}% "
  "entre os dias, com 11/11 como o turno com mais peças metálicas.")
figura("03_barras_tipo_dia.png", "Figura 1 — Peças por tipo e por dia.", 11)
figura("02_contagem_acumulada.png", "Figura 2 — Contagem acumulada por tipo em cada turno (retas quase constantes: linha estável).")

doc.add_heading("3.2 Nível do reservatório e taxa de enchimento", 2)


def linha(nome, e, un=""):
    return (nome, f(e["media"]) + un, f(e["mediana"]) + un, f(e["moda"], 0) if e["moda"] is not None else "–",
            f(e["desvio_padrao"]) + un, f"{f(e['q1'])} / {f(e['q3'])}", f"{f(e['minimo'])} / {f(e['maximo'])}", e["outliers"])


tabela(["Variável", "Média", "Mediana", "Moda", "Desvio", "Q1 / Q3", "Mín / Máx", "Outliers"],
       [linha("Nível (%)", r["nivel"]),
        linha("Aumento de nível por leitura (p.p.)", r["taxa_enchimento_por_leitura"]),
        linha("Metálicas por 10 leituras", r["metalicas_por_10"]),
        linha("Não metálicas por 10 leituras", r["nao_metalicas_por_10"])],
       [4.4, 1.6, 1.8, 1.4, 1.6, 2.4, 2.4, 1.6])
nv = r["nivel"]
p(f"O nível tem média {f(nv['media'], 1)}% e mediana {f(nv['mediana'], 1)}%, praticamente iguais, e desvio padrão alto "
  f"({f(nv['desvio_padrao'], 1)} p.p.). Isso não indica instabilidade: é o efeito do ciclo \"enche e esvazia\", em que o "
  "reservatório percorre toda a faixa de 3% a 91%. A moda (8%) é pouco informativa pelo mesmo motivo — o histograma é "
  "aproximadamente uniforme.")
figura("01_nivel_linha.png", "Figura 3 — Nível do reservatório por turno (dente de serra); pontos vermelhos = enchimento acelerado.")
figura("04_histograma_nivel.png", "Figura 4 — Histograma do nível: distribuição aproximadamente uniforme entre os esvaziamentos.", 11)
figura("05_boxplot_nivel.png", "Figura 5 — Boxplot do nível: sem outliers (as cercas ficam fora da escala 0–100%).", 11)
p("Conclusão desta etapa: olhar apenas a distribuição do nível não revela problemas, porque o dente de serra mascara as "
  "anomalias. Por isso o critério de alerta usa a taxa de enchimento (variação entre leituras), em que o comportamento "
  "normal é estreito e as anomalias se destacam.", bold=True)

doc.add_heading("3.3 Relação entre produção e nível (correlação)", 2)
p(f"Entre as horas de operação, o coeficiente de correlação entre peças por hora e aumento total de nível por hora foi "
  f"r = {f(r['correlacao_pecas_hora_x_aumento_nivel'])}: correlação positiva moderada, como esperado — mais peças "
  "enchem o reservatório mais depressa. Os dois pontos mais altos do gráfico são as horas com os episódios de enchimento "
  "acelerado: sobem o nível sem que a produção seja maior, o que reforça que são anomalias e não aumento de carga.")
figura("07_dispersao_pecas_nivel.png", "Figura 6 — Peças por hora × aumento de nível por hora.", 11)

# ------------------------------------------------------------------ 4
doc.add_heading("4. Outliers e critério de alerta", 1)
tx = r["taxa_enchimento_por_leitura"]; ca = r["criterio_alerta"]
p(f"Na taxa de enchimento, a caixa do boxplot é estreita (Q1 = {f(tx['q1'])}, Q3 = {f(tx['q3'])}, IQR = {f(tx['iqr'])} p.p.) "
  f"e a cerca superior de Tukey (Q3 + 1,5 × IQR) fica em {f(ca['cerca_taxa_enchimento_pp'])} p.p. por leitura. "
  f"{tx['outliers']} leituras ficaram acima da cerca, mas a maioria são picos isolados de ruído do sensor de distância "
  "(a medição tem oscilação de décimos de ponto percentual).")
figura("06_boxplot_taxa_enchimento.png", "Figura 7 — Taxa de enchimento por leitura e a cerca superior usada como critério.", 11)
p("Critério de alerta proposto (implementado em DetectorAlertas.java e no analise.py):", bold=True)
bullets([
    f"NIVEL_CRITICO (severidade danger): o nível cruza o limiar de {f(ca['limiar_nivel_pct'], 0)}% de baixo para cima. "
    "O limiar é configurável (app.analise.limiar-nivel ou parâmetro ?limiar= na API).",
    f"ENCHIMENTO_ACELERADO (severidade warning): o aumento de nível passa de {f(ca['cerca_taxa_enchimento_pp'])} p.p. em "
    "DUAS leituras consecutivas. Exigir a repetição elimina o ruído de uma leitura só.",
])
doc.add_heading("Validação do critério", 2)
p(f"Contra os episódios injetados, o critério detectou {v['episodios_detectados']} de {v['episodios_injetados']} episódios, "
  f"com {v['alertas_falsos']} alertas falsos. Com o critério ingênuo de uma única leitura acima da cerca, o mesmo teste "
  f"gerava 47 alertas, dos quais 27 falsos — por isso a regra das duas leituras seguidas. No período ocorreram "
  f"{r['alertas']['nivel_critico']} alertas de nível crítico (um por ciclo de enchimento, já que o esvaziamento só é feito "
  "depois de passar de 85%) e " f"{r['alertas']['enchimento_acelerado']} alertas de enchimento acelerado, todos nos dois episódios.")
p("Limitação: 18 de 20 leituras anômalas são alertadas porque a regra só dispara na segunda leitura consecutiva — um atraso "
  "de uma leitura (≈ 16 s) aceitável para esta aplicação.", italic=True)

# ------------------------------------------------------------------ 5
doc.add_heading("5. Integração com o back-end (API REST)", 1)
p("A análise foi levada para dentro da API Spring Boot, usando exatamente os mesmos cálculos do relatório "
  "(conferido: média, mediana, moda, desvio, quartis, cerca e contagem de alertas são idênticos aos do Python).")
tabela(["Endpoint", "O que retorna"],
       [("GET /api/analise/resumo?limite=1000&limiar=85", "Total por tipo, % metálicas, estatística descritiva do nível e da taxa de enchimento, cerca e limiar usados"),
        ("GET /api/analise/alertas?limite=1000&limiar=85", "Lista de alertas (id, tipo, severidade, timestamp, mensagem), do mais recente ao mais antigo")],
       [7, 9.5])
p("Classes: EstatisticaDescritiva e DetectorAlertas (lógica pura, com testes unitários), AnaliseService, AnaliseController e DTOs "
  "(EstatisticasDTO, AlertaDTO, AnaliseResumoDTO). O formato dos alertas é o mesmo já usado pelo dashboard (alerts.js), então a "
  "página Alertas e o app de Realidade Aumentada podem consumir direto. O perfil h2 sobe com a base simulada carregada "
  "(SeedSimulado), permitindo demonstrar tudo sem a esteira.")

# ------------------------------------------------------------------ 6
doc.add_heading("6. Conclusões", 1)
bullets([
    f"A linha opera de forma estável: ≈ {f(pn['mediana'], 0)} peças/hora, com cerca de 38% de peças metálicas.",
    "O nível do reservatório segue um ciclo regular de enchimento e esvaziamento; a distribuição do nível sozinha (histograma, "
    "boxplot) não detecta falhas, mas a taxa de enchimento sim.",
    "O critério de alerta em duas camadas (nível ≥ limiar e enchimento acima da cerca de Tukey em duas leituras seguidas) "
    "detectou todos os episódios simulados sem falsos positivos.",
    "Recomendação operacional: programar o esvaziamento quando o nível passar de ≈ 75–80%, antes do alerta crítico, "
    "dado que o ciclo normal leva cerca de uma hora para chegar aos 85%.",
    "Próximo passo: repetir a análise com dados reais da esteira (exportar leitura do MySQL em CSV e rodar analise.py), "
    "reavaliando o limiar e a cerca com a variabilidade real do sensor.",
])
doc.save(AQUI / "Relatorio_Ciencia_de_Dados.docx")
print("ok", quedas, round(intervalo.mean(), 1))

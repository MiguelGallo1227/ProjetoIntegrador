"""
Ciência de Dados - MetalTech (Projeto Interdisciplinar II)

Gera uma base simulada com o MESMO formato da tabela `leitura` do back-end
(data_hora, tipo_peca, nivel_reservatorio), aplica estatística descritiva,
detecta outliers/anomalias, gera os gráficos e salva resultados.json.

Uso:  python3 analise.py                 -> usa dados simulados (gera o CSV)
      python3 analise.py leituras.csv    -> analisa um CSV exportado do MySQL
          (colunas: data_hora, tipo_peca, nivel_reservatorio)
"""
import json, sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

AQUI = Path(__file__).parent
LIMIAR_NIVEL = 85.0          # % - mesmo limiar padrão do dashboard
COR_METAL, COR_NAO, COR_ALERTA, COR_NIVEL = "#2563b8", "#d9822b", "#c0392b", "#4b5563"


# ----------------------------------------------------------------- dados simulados
def simular(seed=42):
    """3 turnos de 8 h. Reservatório enche a cada peça e é esvaziado ao passar de ~90%.
    Injeta 2 episódios de enchimento acelerado (ex.: peças maiores / saída bloqueada)."""
    rng = np.random.default_rng(seed)
    linhas, nivel = [], 5.0
    for dia in range(3):
        t = pd.Timestamp("2026-11-10 08:00", tz="UTC") + pd.Timedelta(days=dia)
        fim = t + pd.Timedelta(hours=8)
        p_metal = [0.35, 0.42, 0.38][dia]
        anomalias = []   # (inicio_idx, duracao)
        n = 0
        rapido_ate = -1
        while t < fim:
            t += pd.Timedelta(seconds=float(rng.gamma(4.0, 4.0)))      # ~16 s entre peças
            n += 1
            if dia in (1, 2) and n in (260 + 120 * dia, ):             # início de anomalia
                rapido_ate = n + 9
            inc = max(0.05, rng.normal(0.42, 0.10))
            inj = n <= rapido_ate
            if inj:
                inc *= rng.uniform(4.0, 6.0)
            nivel += inc
            if nivel >= 91:                                            # operador esvazia
                nivel = float(rng.uniform(3, 8))
            linhas.append((t, "METALICA" if rng.random() < p_metal else "NAO_METALICA",
                           round(min(nivel, 100.0) + rng.normal(0, 0.15), 2), inj))
    return pd.DataFrame(linhas, columns=["data_hora", "tipo_peca", "nivel_reservatorio", "injetada"])


# ----------------------------------------------------------------- estatística
def descrever(v):
    v = pd.Series(v).dropna()
    q1, q3 = v.quantile(.25), v.quantile(.75)          # interpolação linear (igual ao back-end/front)
    iqr = q3 - q1
    inf, sup = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    moda = v.round().mode()
    return dict(n=int(len(v)), media=v.mean(), mediana=v.median(),
                moda=float(moda.iloc[0]) if len(moda) else None,
                desvio_padrao=v.std(ddof=1), minimo=v.min(), maximo=v.max(),
                q1=q1, q3=q3, iqr=iqr, cerca_inferior=inf, cerca_superior=sup,
                outliers=int(((v < inf) | (v > sup)).sum()))


def main():
    if len(sys.argv) > 1:
        df = pd.read_csv(sys.argv[1], parse_dates=["data_hora"])
    else:
        df = simular()
        # formato ISO-8601 (UTC) que o back-end (SeedSimulado) lê com Instant.parse
        out = df.drop(columns="injetada").copy()
        out["data_hora"] = out["data_hora"].dt.strftime("%Y-%m-%dT%H:%M:%S.%f").str[:-3] + "Z"
        out.to_csv(AQUI / "dados" / "leituras_simuladas.csv", index=False)
    df["data_hora"] = pd.to_datetime(df["data_hora"], utc=True)
    df = df.sort_values("data_hora").reset_index(drop=True)
    df["dia"] = df["data_hora"].dt.strftime("%d/%m")
    df["metalica"] = (df["tipo_peca"] == "METALICA").astype(int)

    # taxa de enchimento: variação de nível entre leituras consecutivas (só aumentos)
    df["delta"] = df["nivel_reservatorio"].diff()
    taxas = df.loc[df["delta"] > 0, "delta"]
    st_taxa = descrever(taxas)
    cerca_taxa = st_taxa["cerca_superior"]
    # critério: 2 leituras CONSECUTIVAS acima da cerca (um único pico isolado é ruído do sensor)
    acima = df["delta"] > cerca_taxa
    df["enchimento_acelerado"] = acima & acima.shift(1, fill_value=False)
    df["nivel_critico"] = (df["nivel_reservatorio"] >= LIMIAR_NIVEL) & \
                          (df["nivel_reservatorio"].shift(1) < LIMIAR_NIVEL)

    # peças por hora e tendência
    por_hora = (df.set_index("data_hora").groupby([pd.Grouper(freq="h"), "tipo_peca"]).size()
                  .unstack(fill_value=0).reindex(columns=["METALICA", "NAO_METALICA"], fill_value=0))
    por_hora = por_hora[por_hora.sum(axis=1) > 20]          # ignora horas fora do turno
    por_hora["total"] = por_hora.sum(axis=1)
    # correlação: pecas/hora x aumento médio de nível na hora
    inc_hora = df.set_index("data_hora")["delta"].clip(lower=0).resample("h").sum().reindex(por_hora.index)
    corr = float(np.corrcoef(por_hora["total"], inc_hora)[0, 1])

    validacao = None
    if "injetada" in df:      # só existe na base simulada: mede o critério contra a verdade conhecida
        ep = (df.injetada != df.injetada.shift()).cumsum()[df.injetada]     # id de cada episódio
        det = df.enchimento_acelerado.groupby(ep).any()
        falsos = int((df.enchimento_acelerado & ~df.injetada).sum())
        validacao = dict(episodios_injetados=int(len(det)), episodios_detectados=int(det.sum()),
                         leituras_anomalas=int(df.injetada.sum()),
                         leituras_alertadas_corretas=int((df.enchimento_acelerado & df.injetada).sum()),
                         alertas_falsos=falsos)

    # janelas de 10 leituras (mesmo critério da página Análises do dashboard)
    w = 10
    jan = [df["metalica"].iloc[i:i + w].sum() for i in range(0, len(df) - w + 1, w)]

    res = dict(
        periodo=[str(df.data_hora.min()), str(df.data_hora.max())],
        total_pecas=int(len(df)),
        metalicas=int(df.metalica.sum()), nao_metalicas=int(len(df) - df.metalica.sum()),
        proporcao_metalicas_pct=round(100 * df.metalica.mean(), 1),
        por_dia={d: dict(total=int(len(g)), metalicas=int(g.metalica.sum()),
                         nao_metalicas=int(len(g) - g.metalica.sum()),
                         pct_metalicas=round(100 * g.metalica.mean(), 1))
                 for d, g in df.groupby("dia")},
        nivel=descrever(df.nivel_reservatorio),
        taxa_enchimento_por_leitura=st_taxa,
        metalicas_por_10=descrever(jan),
        nao_metalicas_por_10=descrever([w - j for j in jan]),
        pecas_por_hora=descrever(por_hora["total"]),
        correlacao_pecas_hora_x_aumento_nivel=round(corr, 3),
        criterio_alerta=dict(limiar_nivel_pct=LIMIAR_NIVEL, cerca_taxa_enchimento_pp=round(cerca_taxa, 3)),
        validacao_criterio=validacao,
        alertas=dict(enchimento_acelerado=int(df.enchimento_acelerado.sum()),
                     nivel_critico=int(df.nivel_critico.sum())),
    )
    # converte numpy -> float
    res = json.loads(json.dumps(res, default=lambda o: round(float(o), 4)))
    (AQUI / "dados" / "resultados.json").write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
    df.to_csv(AQUI / "dados" / "leituras_com_alertas.csv", index=False)

    graficos(df, por_hora, cerca_taxa, res)
    print(json.dumps({k: res[k] for k in ("total_pecas", "proporcao_metalicas_pct", "criterio_alerta", "alertas", "validacao_criterio",
                                          "correlacao_pecas_hora_x_aumento_nivel")}, indent=2))


# ----------------------------------------------------------------- gráficos
def estilo(ax, titulo, x=None, y=None):
    ax.set_title(titulo, loc="left", fontsize=11, fontweight="bold", color="#1f2937")
    ax.set_xlabel(x or "", fontsize=9, color="#4b5563"); ax.set_ylabel(y or "", fontsize=9, color="#4b5563")
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    for s in ("left", "bottom"): ax.spines[s].set_color("#9ca3af")
    ax.grid(axis="y", color="#e5e7eb", lw=.8); ax.set_axisbelow(True)
    ax.tick_params(labelsize=8, colors="#4b5563")


def salvar(fig, nome):
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / nome, dpi=160); plt.close(fig)


def graficos(df, por_hora, cerca, res):
    dias = list(df.groupby(df.data_hora.dt.date))
    # 1. evolução do nível (linha) + alertas, um painel por turno (sem ligar noites)
    fig, axs = plt.subplots(1, len(dias), figsize=(10, 3.6), sharey=True)
    for ax, (dia, gd) in zip(np.atleast_1d(axs), dias):
        ax.plot(gd.data_hora, gd.nivel_reservatorio, color=COR_NIVEL, lw=.8)
        ax.axhline(LIMIAR_NIVEL, color=COR_ALERTA, ls="--", lw=1)
        a = gd[gd.enchimento_acelerado]
        ax.scatter(a.data_hora, a.nivel_reservatorio, s=22, color=COR_ALERTA, zorder=3)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Hh")); ax.set_ylim(0, 105)
        estilo(ax, pd.Timestamp(dia).strftime("%d/%m"), None, "Nível (%)" if ax is np.atleast_1d(axs)[0] else None)
    np.atleast_1d(axs)[0].text(df.data_hora.iloc[0], LIMIAR_NIVEL + 2, f"limiar {LIMIAR_NIVEL:.0f}%", color=COR_ALERTA, fontsize=8)
    fig.suptitle("Nível do reservatório por turno (pontos vermelhos = enchimento acelerado, 2 leituras seguidas)",
                 x=0.01, ha="left", fontsize=10, fontweight="bold", color="#1f2937")
    fig.tight_layout(rect=(0, 0, 1, .94)); fig.savefig(AQUI / "graficos" / "01_nivel_linha.png", dpi=160); plt.close(fig)

    # 2. contagem acumulada por tipo (linha), reiniciando a cada turno
    fig, axs = plt.subplots(1, len(dias), figsize=(10, 3.6), sharey=True)
    for ax, (dia, gd) in zip(np.atleast_1d(axs), dias):
        for tipo, cor, nome in (("METALICA", COR_METAL, "Metálica"), ("NAO_METALICA", COR_NAO, "Não metálica")):
            sd = gd[gd.tipo_peca == tipo]
            ax.plot(sd.data_hora, np.arange(1, len(sd) + 1), color=cor, lw=1.6, label=nome)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Hh"))
        estilo(ax, pd.Timestamp(dia).strftime("%d/%m"), None, "Peças acumuladas" if ax is np.atleast_1d(axs)[0] else None)
    np.atleast_1d(axs)[0].legend(frameon=False, fontsize=8, loc="upper left")
    fig.suptitle("Contagem acumulada de peças por tipo (por turno)", x=0.01, ha="left", fontsize=10,
                 fontweight="bold", color="#1f2937")
    fig.tight_layout(rect=(0, 0, 1, .94)); fig.savefig(AQUI / "graficos" / "02_contagem_acumulada.png", dpi=160); plt.close(fig)

    # 3. barras: proporção por dia
    d = pd.DataFrame(res["por_dia"]).T
    fig, ax = plt.subplots(figsize=(6, 3.6))
    x = np.arange(len(d)); lg = .38
    b1 = ax.bar(x - lg / 2, d.metalicas, lg, color=COR_METAL, label="Metálica")
    b2 = ax.bar(x + lg / 2, d.nao_metalicas, lg, color=COR_NAO, label="Não metálica")
    for bars in (b1, b2):
        ax.bar_label(bars, fontsize=8, color="#374151", padding=2)
    ax.set_xticks(x, d.index); ax.set_ylim(0, d.nao_metalicas.max() * 1.25); ax.legend(frameon=False, fontsize=8, ncol=2, loc="upper left")
    estilo(ax, "Peças por tipo e por dia", "Dia", "Peças")
    salvar(fig, "03_barras_tipo_dia.png")

    # 4. histograma do nível
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.hist(df.nivel_reservatorio, bins=np.arange(0, 101, 10), color=COR_NIVEL, edgecolor="white")
    estilo(ax, "Histograma do nível do reservatório", "Nível (%)", "Leituras")
    salvar(fig, "04_histograma_nivel.png")

    # 5. boxplot do nível
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.boxplot([df.nivel_reservatorio], orientation='horizontal', widths=.5, patch_artist=True,
               boxprops=dict(facecolor="#cbd5e1", color=COR_NIVEL), medianprops=dict(color=COR_NAO, lw=2),
               flierprops=dict(marker="o", markerfacecolor=COR_ALERTA, markeredgecolor=COR_ALERTA, ms=4))
    ax.set_yticks([])
    estilo(ax, "Boxplot do nível do reservatório", "Nível (%)")
    ax.grid(axis="x", color="#e5e7eb"); ax.grid(axis="y", visible=False)
    salvar(fig, "05_boxplot_nivel.png")

    # 6. boxplot da taxa de enchimento + cerca (critério de alerta)
    taxas = df.loc[df.delta > 0, "delta"]
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.boxplot([taxas], orientation='horizontal', widths=.5, patch_artist=True,
               boxprops=dict(facecolor="#cbd5e1", color=COR_NIVEL), medianprops=dict(color=COR_NAO, lw=2),
               flierprops=dict(marker="o", markerfacecolor=COR_ALERTA, markeredgecolor=COR_ALERTA, ms=4))
    ax.axvline(cerca, color=COR_ALERTA, ls="--", lw=1)
    ax.text(cerca, 1.38, f" cerca Q3+1,5·IQR = {cerca:.2f} p.p.", color=COR_ALERTA, fontsize=8)
    ax.set_yticks([])
    estilo(ax, "Taxa de enchimento por leitura (critério de alerta)", "Aumento de nível (p.p.)")
    ax.grid(axis="x", color="#e5e7eb"); ax.grid(axis="y", visible=False)
    salvar(fig, "06_boxplot_taxa_enchimento.png")

    # 7. dispersão: peças/hora x aumento de nível/hora
    inc = df.set_index("data_hora")["delta"].clip(lower=0).resample("h").sum().reindex(por_hora.index)
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.scatter(por_hora.total, inc, s=30, color=COR_METAL)
    estilo(ax, f"Peças por hora × aumento de nível (r = {res['correlacao_pecas_hora_x_aumento_nivel']:.2f})",
           "Peças por hora", "Aumento de nível (p.p./h)")
    salvar(fig, "07_dispersao_pecas_nivel.png")


if __name__ == "__main__":
    main()

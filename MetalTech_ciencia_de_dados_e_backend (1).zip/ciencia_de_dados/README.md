# Ciência de Dados — MetalTech

| Arquivo | O que é |
|---|---|
| `analise.py` | Gera a base simulada, estatística descritiva, outliers, alertas e os gráficos |
| `gerar_relatorio.py` | Monta `Relatorio_Ciencia_de_Dados.docx` a partir dos resultados |
| `dados/leituras_simuladas.csv` | Base simulada (mesmo formato da tabela `leitura`); copiada para `back-end/.../seed/` |
| `dados/resultados.json` | Todos os números do relatório |
| `graficos/` | 7 gráficos (linha, barras, histograma, 2 boxplots, dispersão) |

```bash
pip install pandas numpy matplotlib python-docx
python3 analise.py                 # base simulada
python3 analise.py leituras.csv    # CSV real exportado do MySQL
python3 gerar_relatorio.py
```
Exportar dados reais: `SELECT data_hora, tipo_peca, nivel_reservatorio FROM leitura ORDER BY data_hora;`
(salvar como CSV com cabeçalho).

package com.senai.ProjetoInterdisciplinar;

import com.senai.ProjetoInterdisciplinar.DTO.LeituraDTO;
import com.senai.ProjetoInterdisciplinar.DTO.LeituraRequestDTO;
import com.senai.ProjetoInterdisciplinar.entity.Leitura;
import com.senai.ProjetoInterdisciplinar.entity.TipoPeca;
import com.senai.ProjetoInterdisciplinar.exception.RecursoNaoEncontradoException;
import com.senai.ProjetoInterdisciplinar.repostory.LeituraRepository;
import com.senai.ProjetoInterdisciplinar.service.LeituraService;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class LeituraServiceTest {

    private final LeituraRepository repo = mock(LeituraRepository.class);
    private final LeituraService service = new LeituraService(repo);

    @Test
    void criarGravaELogoUsaOInstanteAtualSeNaoVierTimestamp() {
        when(repo.save(any(Leitura.class))).thenAnswer(inv -> {
            Leitura l = inv.getArgument(0);
            l.setId(7L);
            return l;
        });
        LeituraDTO d = service.criar(new LeituraRequestDTO(TipoPeca.METALICA, 42.5, null));
        assertEquals(7L, d.getId().longValue());
        assertEquals(TipoPeca.METALICA, d.getTipoPeca());
        assertEquals(42.5, d.getNivelReservatorio(), 1e-9);
        assertNotNull(d.getTimestamp());
    }

    @Test
    void atualizarAlteraTipoENivel() {
        Leitura existente = Leitura.builder().id(1L).dataHora(Instant.parse("2026-11-10T08:00:00Z"))
                .tipoPeca(TipoPeca.METALICA).nivelReservatorio(10.0).build();
        when(repo.findById(1L)).thenReturn(Optional.of(existente));
        when(repo.save(any(Leitura.class))).thenAnswer(inv -> inv.getArgument(0));

        LeituraDTO d = service.atualizar(1L, new LeituraRequestDTO(TipoPeca.NAO_METALICA, 55.0, null));
        assertEquals(TipoPeca.NAO_METALICA, d.getTipoPeca());
        assertEquals(55.0, d.getNivelReservatorio(), 1e-9);
        assertEquals(Instant.parse("2026-11-10T08:00:00Z"), d.getTimestamp()); // sem timestamp novo, mantem
    }

    @Test
    void buscarInexistenteLancaNaoEncontrado() {
        when(repo.findById(9L)).thenReturn(Optional.empty());
        assertThrows(RecursoNaoEncontradoException.class, () -> service.buscar(9L));
    }

    @Test
    void removerExistenteApaga() {
        when(repo.existsById(3L)).thenReturn(true);
        service.remover(3L);
        verify(repo).deleteById(3L);
    }

    @Test
    void removerInexistenteLancaENaoApaga() {
        when(repo.existsById(3L)).thenReturn(false);
        assertThrows(RecursoNaoEncontradoException.class, () -> service.remover(3L));
        verify(repo, never()).deleteById(anyLong());
    }
}

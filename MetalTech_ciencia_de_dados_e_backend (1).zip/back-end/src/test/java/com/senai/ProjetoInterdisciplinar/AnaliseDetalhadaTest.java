package com.senai.ProjetoInterdisciplinar;

import com.senai.ProjetoInterdisciplinar.DTO.AnaliseDetalheDTO;
import com.senai.ProjetoInterdisciplinar.service.AnaliseDetalhada;
import com.senai.ProjetoInterdisciplinar.service.DetectorAlertas.Ponto;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AnaliseDetalhadaTest {

    private List<Ponto> serie() {
        List<Ponto> s = new ArrayList<>();
        Instant t0 = Instant.parse("2026-11-10T08:00:00Z");
        for (int i = 0; i < 40; i++) {                       // 40 pecas, 1 a cada 30 s, nivel 5..44
            s.add(new Ponto((long) i, t0.plusSeconds(i * 30L), i % 4 == 0, 5 + i));
        }
        return s;
    }

    @Test
    void contaPorDiaEHistograma() {
        AnaliseDetalheDTO d = AnaliseDetalhada.calcular(serie(), ZoneId.of("UTC"));
        assertEquals(1, d.porDia().size());
        assertEquals("10/11", d.porDia().get(0).dia());
        assertEquals(40, d.porDia().get(0).total());
        assertEquals(10, d.porDia().get(0).metalicas());      // i = 0,4,8,...,36
        assertEquals(30, d.porDia().get(0).naoMetalicas());
        assertEquals(10, d.histogramaNivel().size());
        assertEquals(5, d.histogramaNivel().get(0).quantidade());   // niveis 5..9
        assertEquals(10, d.histogramaNivel().get(1).quantidade());  // niveis 10..19
    }

    @Test
    void janelasDe10() {
        AnaliseDetalheDTO d = AnaliseDetalhada.calcular(serie(), ZoneId.of("UTC"));
        assertEquals(4, d.metalicasPor10Leituras().n());
        assertEquals(2.5, d.metalicasPor10Leituras().media(), 1e-9);
        assertEquals(7.5, d.naoMetalicasPor10Leituras().media(), 1e-9);
    }
}

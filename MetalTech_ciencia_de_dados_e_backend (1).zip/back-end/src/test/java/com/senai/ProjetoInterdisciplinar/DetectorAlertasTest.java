package com.senai.ProjetoInterdisciplinar;

import com.senai.ProjetoInterdisciplinar.DTO.AlertaDTO;
import com.senai.ProjetoInterdisciplinar.service.DetectorAlertas;
import com.senai.ProjetoInterdisciplinar.service.DetectorAlertas.Ponto;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DetectorAlertasTest {

    private final Instant t0 = Instant.parse("2026-11-10T08:00:00Z");

    /** Serie que sobe 0,4 p.p. por leitura, com os saltos informados (indice -> aumento). */
    private List<Ponto> serie(int n, double inicio, java.util.Map<Integer, Double> saltos) {
        List<Ponto> s = new ArrayList<>();
        double nivel = inicio;
        for (int i = 0; i < n; i++) {
            nivel += saltos.getOrDefault(i, 0.4 + (i % 3) * 0.05);
            s.add(new Ponto((long) i, t0.plusSeconds(i * 15L), i % 3 == 0, nivel));
        }
        return s;
    }

    private long contar(List<AlertaDTO> a, String tipo) {
        return a.stream().filter(x -> x.tipo().equals(tipo)).count();
    }

    @Test
    void picoIsoladoNaoGeraAlertaDeEnchimento() {
        var r = DetectorAlertas.detectar(serie(100, 5, java.util.Map.of(50, 3.0)), 95);
        assertEquals(0, contar(r.alertas(), "ENCHIMENTO_ACELERADO"));
    }

    @Test
    void duasLeiturasRapidasSeguidasGeramAlerta() {
        var r = DetectorAlertas.detectar(serie(100, 5, java.util.Map.of(50, 3.0, 51, 3.2)), 95);
        assertEquals(1, contar(r.alertas(), "ENCHIMENTO_ACELERADO"));
        assertEquals("warning", r.alertas().get(0).severidade());
    }

    @Test
    void cruzarOLimiarGeraAlertaCritico() {
        var r = DetectorAlertas.detectar(serie(60, 60, java.util.Map.of()), 80);
        assertEquals(1, contar(r.alertas(), "NIVEL_CRITICO"));   // cruza uma unica vez
        assertTrue(r.alertas().stream().anyMatch(a -> a.severidade().equals("danger")));
    }

    @Test
    void serieCurtaNaoQuebra() {
        assertTrue(DetectorAlertas.detectar(List.of(), 85).alertas().isEmpty());
    }
}

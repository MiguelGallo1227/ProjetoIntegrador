package com.senai.ProjetoInterdisciplinar;

import com.senai.ProjetoInterdisciplinar.DTO.LeituraDTO;
import com.senai.ProjetoInterdisciplinar.DTO.LeituraRequestDTO;
import com.senai.ProjetoInterdisciplinar.controller.LeituraController;
import com.senai.ProjetoInterdisciplinar.entity.TipoPeca;
import com.senai.ProjetoInterdisciplinar.exception.ApiExceptionHandler;
import com.senai.ProjetoInterdisciplinar.exception.RecursoNaoEncontradoException;
import com.senai.ProjetoInterdisciplinar.service.LeituraService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Testa o controller isolado (sem subir o Spring inteiro nem o banco). */
class LeituraControllerTest {

    private final LeituraService service = mock(LeituraService.class);
    private final MockMvc mvc = MockMvcBuilders.standaloneSetup(new LeituraController(service))
            .setControllerAdvice(new ApiExceptionHandler())
            .build();

    private LeituraDTO dto(long id, TipoPeca tipo, double nivel) {
        return LeituraDTO.builder().id(id).timestamp(Instant.parse("2026-11-10T08:00:00Z"))
                .tipoPeca(tipo).nivelReservatorio(nivel).build();
    }

    @Test
    void postValidoRetorna201ComLocation() throws Exception {
        when(service.criar(any(LeituraRequestDTO.class))).thenReturn(dto(5, TipoPeca.METALICA, 42.5));
        mvc.perform(post("/api/leituras").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tipoPeca\":\"METALICA\",\"nivelReservatorio\":42.5}"))
                .andExpect(status().isCreated())
                .andExpect(r -> assertTrue(r.getResponse().getHeader("Location").endsWith("/api/leituras/5")))
                .andExpect(r -> assertTrue(r.getResponse().getContentAsString().contains("METALICA")));
    }

    @Test
    void postComNivelForaDaFaixaRetorna400() throws Exception {
        mvc.perform(post("/api/leituras").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tipoPeca\":\"METALICA\",\"nivelReservatorio\":150}"))
                .andExpect(status().isBadRequest())
                .andExpect(r -> assertTrue(r.getResponse().getContentAsString().contains("nivelReservatorio")));
    }

    @Test
    void postSemTipoRetorna400() throws Exception {
        mvc.perform(post("/api/leituras").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nivelReservatorio\":10}"))
                .andExpect(status().isBadRequest())
                .andExpect(r -> assertTrue(r.getResponse().getContentAsString().contains("tipoPeca")));
    }

    @Test
    void tipoDePecaInvalidoRetorna400() throws Exception {
        mvc.perform(post("/api/leituras").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tipoPeca\":\"PLASTICO\",\"nivelReservatorio\":10}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getInexistenteRetorna404() throws Exception {
        when(service.buscar(9L)).thenThrow(new RecursoNaoEncontradoException("Leitura 9 nao encontrada."));
        mvc.perform(get("/api/leituras/9")).andExpect(status().isNotFound());
    }

    @Test
    void idNaoNumericoRetorna400() throws Exception {
        mvc.perform(get("/api/leituras/abc")).andExpect(status().isBadRequest());
    }

    @Test
    void putValidoRetorna200() throws Exception {
        when(service.atualizar(eq(2L), any(LeituraRequestDTO.class))).thenReturn(dto(2, TipoPeca.NAO_METALICA, 30));
        mvc.perform(put("/api/leituras/2").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tipoPeca\":\"NAO_METALICA\",\"nivelReservatorio\":30}"))
                .andExpect(status().isOk());
    }

    @Test
    void deleteRetorna204() throws Exception {
        mvc.perform(delete("/api/leituras/4")).andExpect(status().isNoContent());
        verify(service).remover(4L);
    }
}

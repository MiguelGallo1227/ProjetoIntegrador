package com.senai.ProjetoInterdisciplinar;

import com.senai.ProjetoInterdisciplinar.DTO.EstatisticasDTO;
import com.senai.ProjetoInterdisciplinar.service.EstatisticaDescritiva;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class EstatisticaDescritivaTest {

    @Test
    void calculaMediaMedianaModaDesvioEQuartis() {
        EstatisticasDTO e = EstatisticaDescritiva.descrever(new double[]{2, 4, 4, 4, 5, 5, 7, 9});
        assertEquals(8, e.n());
        assertEquals(5.0, e.media(), 1e-9);
        assertEquals(4.5, e.mediana(), 1e-9);
        assertEquals(4.0, e.moda(), 1e-9);
        assertEquals(2.13809, e.desvioPadrao(), 1e-5);   // amostral (n-1)
        assertEquals(4.0, e.q1(), 1e-9);
        assertEquals(5.5, e.q3(), 1e-9);
        assertEquals(1.5, e.iqr(), 1e-9);
        assertEquals(1, e.outliers());                   // 9 > 5,5 + 1,5*1,5 = 7,75
    }

    @Test
    void listaVaziaNaoQuebra() {
        EstatisticasDTO e = EstatisticaDescritiva.descrever(new double[0]);
        assertEquals(0, e.n());
        assertNull(e.moda());
    }
}

package com.senai.ProjetoInterdisciplinar.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Documentacao da API (Swagger UI em /swagger-ui.html, JSON em /v3/api-docs). */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI metalTechOpenApi() {
        return new OpenAPI().info(new Info()
                .title("API MetalTech - Esteira de triagem")
                .version("1.0")
                .description("Leituras da esteira, status, historico dos sensores e analises estatisticas "
                        + "(Ciencia de Dados). Consumida pelo dashboard React e pelo app de Realidade Aumentada."));
    }
}

package com.senai.ProjetoInterdisciplinar.DTO;

import java.time.Instant;

/** GET /api/analise/resumo */
public record AnaliseResumoDTO(
        Instant periodoInicio,
        Instant periodoFim,
        int totalPecas,
        long metalicas,
        long naoMetalicas,
        double proporcaoMetalicasPct,
        EstatisticasDTO nivelReservatorio,
        EstatisticasDTO taxaEnchimento,
        double limiarNivelPct,
        double cercaTaxaEnchimento,
        int totalAlertas) {
}

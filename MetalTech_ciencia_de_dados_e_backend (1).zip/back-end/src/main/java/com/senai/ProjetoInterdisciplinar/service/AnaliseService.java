package com.senai.ProjetoInterdisciplinar.service;

import com.senai.ProjetoInterdisciplinar.DTO.AlertaDTO;
import com.senai.ProjetoInterdisciplinar.DTO.AnaliseDetalheDTO;
import com.senai.ProjetoInterdisciplinar.DTO.AnaliseResumoDTO;
import com.senai.ProjetoInterdisciplinar.entity.Leitura;
import com.senai.ProjetoInterdisciplinar.entity.TipoPeca;
import com.senai.ProjetoInterdisciplinar.repostory.LeituraRepository;
import com.senai.ProjetoInterdisciplinar.service.DetectorAlertas.Ponto;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Camada de Ciencia de Dados: le as leituras gravadas e devolve estatisticas e alertas. */
@Service
@RequiredArgsConstructor
public class AnaliseService {

    private static final int LIMITE_MAXIMO = 5000;

    private final LeituraRepository repository;

    @Value("${app.analise.limiar-nivel:85}")
    private double limiarPadrao;

    public double getLimiarPadrao() {
        return limiarPadrao;
    }

    public AnaliseResumoDTO resumo(int limite, Double limiar) {
        double lim = limiar != null ? limiar : limiarPadrao;
        List<Ponto> serie = serie(limite);
        var det = DetectorAlertas.detectar(serie, lim);

        long metalicas = serie.stream().filter(Ponto::metalica).count();
        double[] niveis = serie.stream().mapToDouble(Ponto::nivel).toArray();
        double pct = serie.isEmpty() ? 0 : 100.0 * metalicas / serie.size();

        return new AnaliseResumoDTO(
                serie.isEmpty() ? null : serie.get(0).instante(),
                serie.isEmpty() ? null : serie.get(serie.size() - 1).instante(),
                serie.size(), metalicas, serie.size() - metalicas, pct,
                EstatisticaDescritiva.descrever(niveis), det.taxaEnchimento(),
                lim, det.cercaTaxa(), det.alertas().size());
    }

    public List<AlertaDTO> alertas(int limite, Double limiar) {
        double lim = limiar != null ? limiar : limiarPadrao;
        return DetectorAlertas.detectar(serie(limite), lim).alertas();
    }

    public AnaliseDetalheDTO detalhe(int limite) {
        return AnaliseDetalhada.calcular(serie(limite), ZoneId.systemDefault());
    }

    /** Ultimas {@code limite} leituras em ordem cronologica crescente. */
    private List<Ponto> serie(int limite) {
        int n = Math.min(Math.max(limite, 2), LIMITE_MAXIMO);
        List<Leitura> recentes = new ArrayList<>(repository.findAllByOrderByDataHoraDesc(PageRequest.of(0, n)));
        Collections.reverse(recentes);
        return recentes.stream()
                .map(l -> new Ponto(l.getId(), l.getDataHora(), l.getTipoPeca() == TipoPeca.METALICA,
                        l.getNivelReservatorio()))
                .toList();
    }
}

package com.senai.ProjetoInterdisciplinar.exception;

/** Lancada quando um registro pedido pelo id nao existe (vira HTTP 404). */
public class RecursoNaoEncontradoException extends RuntimeException {

    public RecursoNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}

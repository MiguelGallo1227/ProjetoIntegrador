package com.senai.ProjetoInterdisciplinar.DTO;

/** Estatistica descritiva de uma serie numerica (media, mediana, moda, desvio, quartis, outliers). */
public record EstatisticasDTO(
        int n,
        double media,
        double mediana,
        Double moda,
        double desvioPadrao,
        double minimo,
        double maximo,
        double q1,
        double q3,
        double iqr,
        double cercaInferior,
        double cercaSuperior,
        int outliers) {
}

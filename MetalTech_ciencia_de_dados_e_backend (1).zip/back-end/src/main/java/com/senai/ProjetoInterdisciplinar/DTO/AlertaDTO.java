package com.senai.ProjetoInterdisciplinar.DTO;

import java.time.Instant;

/** Alerta gerado pela analise. tipo: NIVEL_CRITICO | ENCHIMENTO_ACELERADO; severidade: danger | warning. */
public record AlertaDTO(String id, String tipo, String severidade, Instant timestamp, String mensagem) {
}

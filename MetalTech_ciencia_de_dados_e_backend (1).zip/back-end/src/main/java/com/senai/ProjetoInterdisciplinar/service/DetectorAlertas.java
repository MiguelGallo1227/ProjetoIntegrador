package com.senai.ProjetoInterdisciplinar.service;

import com.senai.ProjetoInterdisciplinar.DTO.AlertaDTO;
import com.senai.ProjetoInterdisciplinar.DTO.EstatisticasDTO;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Criterio de alerta definido pela Ciencia de Dados (ver relatorio):
 * <ol>
 *   <li>NIVEL_CRITICO: o nivel cruza o limiar (de baixo para cima).</li>
 *   <li>ENCHIMENTO_ACELERADO: o aumento de nivel entre leituras consecutivas fica acima da cerca
 *       superior do boxplot (Q3 + 1,5 x IQR) em DUAS leituras seguidas. Um pico isolado e ruido do
 *       sensor de distancia; so a repeticao indica enchimento fora do padrao.</li>
 * </ol>
 * Classe pura (sem Spring/JPA) para ser facil de testar.
 */
public final class DetectorAlertas {

    /** Ponto da serie: uma leitura do banco reduzida ao que a analise usa. */
    public record Ponto(Long id, Instant instante, boolean metalica, double nivel) {
    }

    public record Resultado(EstatisticasDTO taxaEnchimento, double cercaTaxa, List<AlertaDTO> alertas) {
    }

    private DetectorAlertas() {
    }

    /** Aumentos de nivel (> 0) entre leituras consecutivas. */
    public static double[] taxas(List<Ponto> serie) {
        return java.util.stream.IntStream.range(1, serie.size())
                .mapToDouble(i -> serie.get(i).nivel() - serie.get(i - 1).nivel())
                .filter(d -> d > 0)
                .toArray();
    }

    /** @param serie leituras em ordem cronologica crescente */
    public static Resultado detectar(List<Ponto> serie, double limiar) {
        List<AlertaDTO> alertas = new ArrayList<>();
        EstatisticasDTO st = EstatisticaDescritiva.descrever(taxas(serie));
        double cerca = st.cercaSuperior();

        boolean anteriorAcima = false;
        for (int i = 1; i < serie.size(); i++) {
            Ponto prev = serie.get(i - 1);
            Ponto cur = serie.get(i);
            double delta = cur.nivel() - prev.nivel();

            boolean acima = st.n() > 0 && delta > cerca;
            if (acima && anteriorAcima) {
                alertas.add(new AlertaDTO("taxa-" + cur.id(), "ENCHIMENTO_ACELERADO", "warning", cur.instante(),
                        String.format(Locale.ROOT,
                                "Reservatorio enchendo mais rapido que o previsto: +%.1f p.p. por leitura (limite estatistico %.2f).",
                                delta, cerca)));
            }
            anteriorAcima = acima;

            if (prev.nivel() < limiar && cur.nivel() >= limiar) {
                alertas.add(new AlertaDTO("nivel-" + cur.id(), "NIVEL_CRITICO", "danger", cur.instante(),
                        String.format(Locale.ROOT,
                                "Reservatorio atingiu %.1f%%, acima do limiar de %.0f%%. Programe o esvaziamento.",
                                cur.nivel(), limiar)));
            }
        }
        alertas.sort(Comparator.comparing(AlertaDTO::timestamp).reversed());
        return new Resultado(st, cerca, alertas);
    }
}

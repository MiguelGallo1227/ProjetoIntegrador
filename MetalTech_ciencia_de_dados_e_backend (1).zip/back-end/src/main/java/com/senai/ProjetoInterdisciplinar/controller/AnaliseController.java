package com.senai.ProjetoInterdisciplinar.controller;

import com.senai.ProjetoInterdisciplinar.DTO.AlertaDTO;
import com.senai.ProjetoInterdisciplinar.DTO.AnaliseDetalheDTO;
import com.senai.ProjetoInterdisciplinar.DTO.AnaliseResumoDTO;
import com.senai.ProjetoInterdisciplinar.service.AnaliseService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Endpoints da Ciencia de Dados, consumidos pelo dashboard (Analises/Alertas) e pelo app de RA. */
@RestController
@RequestMapping("/api/analise")
@RequiredArgsConstructor
public class AnaliseController {

    private final AnaliseService service;

    /** Estatistica descritiva do nivel e da taxa de enchimento + contagem por tipo. */
    @GetMapping("/resumo")
    public AnaliseResumoDTO resumo(@RequestParam(defaultValue = "1000") int limite,
                                   @RequestParam(required = false) Double limiar) {
        return service.resumo(limite, limiar);
    }

    /** Contagem por dia, histograma do nivel, pecas por hora e correlacao (base dos graficos do relatorio). */
    @GetMapping("/detalhe")
    public AnaliseDetalheDTO detalhe(@RequestParam(defaultValue = "1000") int limite) {
        return service.detalhe(limite);
    }

    /** Alertas (nivel critico e enchimento acelerado), do mais recente para o mais antigo. */
    @GetMapping("/alertas")
    public List<AlertaDTO> alertas(@RequestParam(defaultValue = "1000") int limite,
                                   @RequestParam(required = false) Double limiar) {
        return service.alertas(limite, limiar);
    }
}

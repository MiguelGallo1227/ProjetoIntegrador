package com.senai.ProjetoInterdisciplinar.service;

import com.senai.ProjetoInterdisciplinar.DTO.AnaliseDetalheDTO;
import com.senai.ProjetoInterdisciplinar.DTO.AnaliseDetalheDTO.Dia;
import com.senai.ProjetoInterdisciplinar.DTO.AnaliseDetalheDTO.Faixa;
import com.senai.ProjetoInterdisciplinar.service.DetectorAlertas.Ponto;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Calculos do relatorio (contagem por dia, histograma, pecas por hora, correlacao). Classe pura. */
public final class AnaliseDetalhada {

    private static final int JANELA = 10;
    private static final int PECAS_MINIMAS_POR_HORA = 20; // ignora horas fora do turno

    private AnaliseDetalhada() {
    }

    /** @param serie leituras em ordem cronologica crescente */
    public static AnaliseDetalheDTO calcular(List<Ponto> serie, ZoneId zona) {
        return new AnaliseDetalheDTO(
                porDia(serie, zona),
                histograma(serie),
                janelas(serie, false),
                janelas(serie, true),
                EstatisticaDescritiva.descrever(pecasPorHora(serie).values().stream()
                        .mapToDouble(h -> h[0]).toArray()),
                correlacao(serie));
    }

    static List<Dia> porDia(List<Ponto> serie, ZoneId zona) {
        var fmt = DateTimeFormatter.ofPattern("dd/MM").withZone(zona);
        Map<String, int[]> dias = new LinkedHashMap<>(); // [total, metalicas]
        for (Ponto p : serie) {
            int[] c = dias.computeIfAbsent(fmt.format(p.instante()), k -> new int[2]);
            c[0]++;
            if (p.metalica()) c[1]++;
        }
        List<Dia> out = new ArrayList<>();
        dias.forEach((d, c) -> out.add(new Dia(d, c[0], c[1], c[0] - c[1], 100.0 * c[1] / c[0])));
        return out;
    }

    static List<Faixa> histograma(List<Ponto> serie) {
        int[] bins = new int[10];
        for (Ponto p : serie) bins[(int) Math.min(9, Math.max(0, Math.floor(p.nivel() / 10)))]++;
        List<Faixa> out = new ArrayList<>();
        for (int i = 0; i < 10; i++) out.add(new Faixa(i * 10, i * 10 + 10, bins[i]));
        return out;
    }

    /** Pecas metalicas (ou nao metalicas) em cada bloco de 10 leituras consecutivas. */
    static com.senai.ProjetoInterdisciplinar.DTO.EstatisticasDTO janelas(List<Ponto> serie, boolean naoMetalicas) {
        List<Double> v = new ArrayList<>();
        for (int i = 0; i + JANELA <= serie.size(); i += JANELA) {
            int m = 0;
            for (int j = i; j < i + JANELA; j++) if (serie.get(j).metalica()) m++;
            v.add((double) (naoMetalicas ? JANELA - m : m));
        }
        return EstatisticaDescritiva.descrever(v.stream().mapToDouble(Double::doubleValue).toArray());
    }

    /** hora -> [pecas, aumento total de nivel (soma dos deltas positivos)], so horas com turno. */
    static Map<Instant, double[]> pecasPorHora(List<Ponto> serie) {
        Map<Instant, double[]> horas = new TreeMap<>();
        for (int i = 0; i < serie.size(); i++) {
            Instant h = serie.get(i).instante().truncatedTo(ChronoUnit.HOURS);
            double[] c = horas.computeIfAbsent(h, k -> new double[2]);
            c[0]++;
            if (i > 0) c[1] += Math.max(0, serie.get(i).nivel() - serie.get(i - 1).nivel());
        }
        horas.values().removeIf(c -> c[0] <= PECAS_MINIMAS_POR_HORA);
        return horas;
    }

    /** Pearson entre pecas por hora e aumento de nivel por hora; null se nao ha dados suficientes. */
    static Double correlacao(List<Ponto> serie) {
        var horas = pecasPorHora(serie).values();
        int n = horas.size();
        if (n < 3) return null;
        double mx = horas.stream().mapToDouble(h -> h[0]).average().orElse(0);
        double my = horas.stream().mapToDouble(h -> h[1]).average().orElse(0);
        double sxy = 0, sxx = 0, syy = 0;
        for (double[] h : horas) {
            sxy += (h[0] - mx) * (h[1] - my);
            sxx += (h[0] - mx) * (h[0] - mx);
            syy += (h[1] - my) * (h[1] - my);
        }
        return sxx == 0 || syy == 0 ? null : sxy / Math.sqrt(sxx * syy);
    }
}

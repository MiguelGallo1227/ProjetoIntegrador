package com.senai.ProjetoInterdisciplinar.service;

import com.senai.ProjetoInterdisciplinar.DTO.LeituraDTO;
import com.senai.ProjetoInterdisciplinar.DTO.LeituraRequestDTO;
import com.senai.ProjetoInterdisciplinar.entity.Leitura;
import com.senai.ProjetoInterdisciplinar.exception.RecursoNaoEncontradoException;
import com.senai.ProjetoInterdisciplinar.repostory.LeituraRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;

/** CRUD de leituras (pecas classificadas). A coleta automatica continua gravando pelo ColetaService. */
@Service
@RequiredArgsConstructor
public class LeituraService {

    private final LeituraRepository repository;

    public LeituraDTO criar(LeituraRequestDTO dados) {
        Leitura nova = Leitura.builder()
                .dataHora(dados.timestamp() != null ? dados.timestamp() : Instant.now())
                .tipoPeca(dados.tipoPeca())
                .nivelReservatorio(dados.nivelReservatorio())
                .build();
        return LeituraDTO.de(repository.save(nova));
    }

    public LeituraDTO buscar(Long id) {
        return LeituraDTO.de(obter(id));
    }

    public LeituraDTO atualizar(Long id, LeituraRequestDTO dados) {
        Leitura leitura = obter(id);
        leitura.setTipoPeca(dados.tipoPeca());
        leitura.setNivelReservatorio(dados.nivelReservatorio());
        if (dados.timestamp() != null) {
            leitura.setDataHora(dados.timestamp());
        }
        return LeituraDTO.de(repository.save(leitura));
    }

    public void remover(Long id) {
        if (!repository.existsById(id)) {
            throw naoEncontrada(id);
        }
        repository.deleteById(id);
    }

    private Leitura obter(Long id) {
        return repository.findById(id).orElseThrow(() -> naoEncontrada(id));
    }

    private RecursoNaoEncontradoException naoEncontrada(Long id) {
        return new RecursoNaoEncontradoException("Leitura " + id + " nao encontrada.");
    }
}

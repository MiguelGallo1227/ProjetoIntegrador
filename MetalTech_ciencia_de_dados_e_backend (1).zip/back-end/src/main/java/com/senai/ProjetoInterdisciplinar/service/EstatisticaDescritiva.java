package com.senai.ProjetoInterdisciplinar.service;

import com.senai.ProjetoInterdisciplinar.DTO.EstatisticasDTO;

import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

/**
 * Estatistica descritiva (Ciencia de Dados). Mesmos criterios do script analise.py e do
 * dashboard: quartis por interpolacao linear, desvio padrao amostral (n-1), moda sobre valores
 * arredondados e outliers pela regra de Tukey (fora de Q1 - 1,5*IQR .. Q3 + 1,5*IQR).
 */
public final class EstatisticaDescritiva {

    private EstatisticaDescritiva() {
    }

    public static double quantil(double[] ordenado, double q) {
        if (ordenado.length == 0) return 0;
        double pos = (ordenado.length - 1) * q;
        int base = (int) Math.floor(pos);
        double resto = pos - base;
        return base + 1 < ordenado.length
                ? ordenado[base] + resto * (ordenado[base + 1] - ordenado[base])
                : ordenado[base];
    }

    public static EstatisticasDTO descrever(double[] valores) {
        int n = valores.length;
        if (n == 0) {
            return new EstatisticasDTO(0, 0, 0, null, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        }
        double[] s = valores.clone();
        Arrays.sort(s);

        double soma = 0;
        for (double v : s) soma += v;
        double media = soma / n;

        double desvio = 0;
        if (n > 1) {
            double acc = 0;
            for (double v : s) acc += (v - media) * (v - media);
            desvio = Math.sqrt(acc / (n - 1));
        }

        double q1 = quantil(s, 0.25);
        double q3 = quantil(s, 0.75);
        double iqr = q3 - q1;
        double inf = q1 - 1.5 * iqr;
        double sup = q3 + 1.5 * iqr;
        int outliers = 0;
        for (double v : s) if (v < inf || v > sup) outliers++;

        return new EstatisticasDTO(n, media, quantil(s, 0.5), moda(s), desvio, s[0], s[n - 1],
                q1, q3, iqr, inf, sup, outliers);
    }

    /** Valor (arredondado) mais frequente; em empate fica o menor. null se nao ha dados. */
    private static Double moda(double[] valores) {
        Map<Long, Integer> freq = new TreeMap<>();
        for (double v : valores) freq.merge(Math.round(v), 1, Integer::sum);
        Long melhor = null;
        int max = 0;
        for (var e : freq.entrySet()) {
            if (e.getValue() > max) {
                max = e.getValue();
                melhor = e.getKey();
            }
        }
        return melhor == null ? null : melhor.doubleValue();
    }
}

package com.senai.ProjetoInterdisciplinar.config;

import com.senai.ProjetoInterdisciplinar.entity.Leitura;
import com.senai.ProjetoInterdisciplinar.entity.TipoPeca;
import com.senai.ProjetoInterdisciplinar.repostory.LeituraRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Carrega a base simulada da Ciencia de Dados (seed/leituras_simuladas.csv, ~5.300 pecas em 3 turnos)
 * na tabela leitura, para demonstrar Analises/Alertas sem a esteira real.
 * Ative com app.seed-simulado=true; so carrega se a tabela estiver vazia.
 */
@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "app.seed-simulado", havingValue = "true")
public class SeedSimulado implements ApplicationRunner {

    private final LeituraRepository repository;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        if (repository.count() > 0) {
            log.info("Seed simulado ignorado: a tabela leitura ja tem dados");
            return;
        }
        List<Leitura> lista = new ArrayList<>();
        try (var br = new BufferedReader(new InputStreamReader(
                new ClassPathResource("seed/leituras_simuladas.csv").getInputStream(), StandardCharsets.UTF_8))) {
            br.readLine(); // cabecalho: data_hora,tipo_peca,nivel_reservatorio
            String linha;
            while ((linha = br.readLine()) != null) {
                if (linha.isBlank()) continue;
                String[] c = linha.split(",");
                lista.add(Leitura.builder()
                        .dataHora(Instant.parse(c[0]))
                        .tipoPeca(TipoPeca.valueOf(c[1]))
                        .nivelReservatorio(Double.parseDouble(c[2]))
                        .build());
            }
        }
        repository.saveAll(lista);
        log.info("Seed simulado: {} leituras carregadas", lista.size());
    }
}

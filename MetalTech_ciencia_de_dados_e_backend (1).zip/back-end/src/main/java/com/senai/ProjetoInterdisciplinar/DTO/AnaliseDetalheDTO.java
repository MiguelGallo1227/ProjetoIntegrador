package com.senai.ProjetoInterdisciplinar.DTO;

import java.util.List;

/** GET /api/analise/detalhe: tudo o que o relatorio de Ciencia de Dados mostra, calculado na API. */
public record AnaliseDetalheDTO(
        List<Dia> porDia,
        List<Faixa> histogramaNivel,
        EstatisticasDTO metalicasPor10Leituras,
        EstatisticasDTO naoMetalicasPor10Leituras,
        EstatisticasDTO pecasPorHora,
        Double correlacaoPecasHoraXAumentoNivel) {

    /** Contagem de um dia (dd/MM). */
    public record Dia(String dia, int total, long metalicas, long naoMetalicas, double pctMetalicas) {
    }

    /** Faixa do histograma: [inicio, fim) em % de nivel. */
    public record Faixa(int inicio, int fim, int quantidade) {
    }
}

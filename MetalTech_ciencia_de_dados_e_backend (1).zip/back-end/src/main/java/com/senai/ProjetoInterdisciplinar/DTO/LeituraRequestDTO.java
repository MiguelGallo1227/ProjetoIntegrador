package com.senai.ProjetoInterdisciplinar.DTO;

import com.senai.ProjetoInterdisciplinar.entity.TipoPeca;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;

/** Corpo de POST/PUT /api/leituras. timestamp e opcional (se vazio, usa o instante atual). */
public record LeituraRequestDTO(
        @NotNull(message = "tipoPeca e obrigatorio (METALICA ou NAO_METALICA)")
        TipoPeca tipoPeca,

        @NotNull(message = "nivelReservatorio e obrigatorio")
        @DecimalMin(value = "0.0", message = "nivelReservatorio deve ser no minimo 0")
        @DecimalMax(value = "100.0", message = "nivelReservatorio deve ser no maximo 100")
        Double nivelReservatorio,

        Instant timestamp) {
}

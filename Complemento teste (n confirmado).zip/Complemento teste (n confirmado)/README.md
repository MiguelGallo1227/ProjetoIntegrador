# MetalTech – Monitoramento (parte de Ciência de Dados em Spring Boot)

Java 17 + Spring Boot 3 + Apache Commons Math 3 + H2 (troque por MySQL/PostgreSQL na nuvem).

## Rodar
    mvn spring-boot:run        # sobe em http://localhost:8080 com 2000 leituras simuladas
    mvn test                   # testes da regressão e das anomalias

## Endpoints
| Método | Rota | O que faz |
|---|---|---|
| GET | /api/estatisticas/resumo | contagem por tipo, nível (média, mediana, desvio, min, max), peças/min, status |
| GET | /api/estatisticas/serie?intervaloMin=5&janela=3 | série agregada + média móvel (gráfico de linha) |
| GET | /api/estatisticas/descritiva?intervaloMin=5&faixaPct=10 | média, mediana, moda, desvio, quartis (nível e contagem por tipo), histograma, boxplot (com outliers IQR) e taxa de enchimento por ciclo com alerta |
| GET | /api/estatisticas/anomalias | lista de anomalias com tipo e severidade |
| GET | /api/estatisticas/previsao-enchimento | minutos até 90% e 100% (regressão linear) |
| POST | /api/leituras | recebe leitura real do sensor/CLP |
| GET | /api/leituras?limite=100 | últimas leituras |
| GET | /api/leituras/export | CSV para Excel/relatório |
| POST | /api/simulador?quantidade=2000&seed=42 | regenera a base simulada |

Todos os GET de estatística aceitam `?inicio=2026-11-10T08:00:00&fim=...`.

## Enviar uma leitura (exemplo)
    curl -X POST localhost:8080/api/leituras -H "Content-Type: application/json" \
      -d '{"distanciaCm": 12.4, "indutivo": true, "capacitivo": false}'

## Trocar simulador pelos sensores reais
Em application.properties: `metaltech.simulador.ao-iniciar=false` e faça o CLP/Node-RED
enviar POST /api/leituras. Ajuste `metaltech.reservatorio.altura-cm` para a altura real.

## Exemplo no React (fetch)
    useEffect(() => {
      const id = setInterval(async () => {
        const r = await fetch("http://localhost:8080/api/estatisticas/resumo");
        setResumo(await r.json());
      }, 3000);
      return () => clearInterval(id);
    }, []);

## Regras de anomalia (ajustáveis em application.properties)
- LEITURA_AUSENTE / LEITURA_INVALIDA: distância nula ou fora de 0..altura
- CONFLITO_SENSORES: indutivo e capacitivo ao mesmo tempo
- SALTO_BRUSCO: z-score > 3 na variação do nível entre leituras (esvaziamento é ignorado)
- SENSOR_TRAVADO: mesma distância em 15+ leituras seguidas
- ESTEIRA_PARADA: nenhuma peça em 30+ leituras seguidas
- NIVEL_CRITICO: nível cruzou 90%

## Critério de alerta de enchimento (item 5.2)
Cada ciclo (entre dois esvaziamentos) recebe uma taxa de enchimento, em p.p. por minuto, por regressão linear.
Alerta quando a taxa do ciclo é maior que 1,5 x a mediana das taxas (`metaltech.enchimento.fator-mediana`).
A mediana é usada no lugar da média porque não é puxada pelos próprios ciclos anômalos.

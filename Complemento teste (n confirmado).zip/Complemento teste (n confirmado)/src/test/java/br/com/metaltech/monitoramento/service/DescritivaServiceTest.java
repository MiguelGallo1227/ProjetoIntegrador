package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DescritivaServiceTest {

    private final Reservatorio reservatorio = new Reservatorio(30, 75, 90);
    private final DescritivaService servico =
            new DescritivaService(reservatorio, new EstatisticaService(reservatorio), 1.5);

    @Test
    void modaQuartisEOutlierDoBoxplot() {
        double[] v = {1, 2, 2, 3, 4, 100};

        Dtos.EstatisticaBasicaDTO b = servico.basica(v, false);
        assertEquals(2.0, b.moda());
        assertTrue(b.q1() <= b.mediana() && b.mediana() <= b.q3());

        Dtos.BoxplotDTO box = servico.boxplot(v);
        assertTrue(box.outliers().contains(100.0), "100 deveria ser outlier pelo IQR");
    }

    @Test
    void histogramaSomaTodasAsLeituras() {
        double[] v = {0, 5, 10, 55, 99.9, 100};
        int soma = servico.histograma(v, 10).stream().mapToInt(Dtos.FaixaHistogramaDTO::quantidade).sum();
        assertEquals(v.length, soma);
        assertEquals(10, servico.histograma(v, 10).size());
    }

    @Test
    void alertaNoCicloQueEncheMaisRapido() {
        // 4 ciclos de 5% a 95%: três a 1 p.p./min (passo 60 s) e um a 3 p.p./min (passo 20 s)
        int[] passos = {60, 60, 20, 60};
        LocalDateTime t0 = LocalDateTime.of(2026, 11, 10, 8, 0);
        List<Leitura> ls = new ArrayList<>();
        long t = 0;
        for (int passo : passos) {
            for (int pct = 5; pct <= 95; pct++) {
                double dist = 30 * (1 - pct / 100.0);
                ls.add(new Leitura(t0.plusSeconds(t), dist, false, false, 0));
                t += passo;
            }
        }

        Dtos.EnchimentoDTO e = servico.descritiva(ls, 5, 10).enchimento();

        assertEquals(4, e.ciclos().size());
        assertEquals(1.0, e.ciclos().get(0).taxaPctPorMin(), 0.05);
        assertEquals(3.0, e.ciclos().get(2).taxaPctPorMin(), 0.05);
        assertFalse(e.ciclos().get(0).alerta());
        assertFalse(e.ciclos().get(1).alerta());
        assertTrue(e.ciclos().get(2).alerta());
        assertFalse(e.ciclos().get(3).alerta());
    }
}

package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.model.Leitura;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/** Regras de negócio do reservatório: conversão distância -> % e identificação de ciclos. */
@Component
public class Reservatorio {

    private final double alturaCm;
    private final double limiteAtencaoPct;
    private final double limiteAlertaPct;

    public Reservatorio(
            @Value("${metaltech.reservatorio.altura-cm:30}") double alturaCm,
            @Value("${metaltech.reservatorio.limite-atencao-pct:75}") double limiteAtencaoPct,
            @Value("${metaltech.reservatorio.limite-alerta-pct:90}") double limiteAlertaPct) {
        this.alturaCm = alturaCm;
        this.limiteAtencaoPct = limiteAtencaoPct;
        this.limiteAlertaPct = limiteAlertaPct;
    }

    public double getAlturaCm() { return alturaCm; }
    public double getLimiteAtencaoPct() { return limiteAtencaoPct; }
    public double getLimiteAlertaPct() { return limiteAlertaPct; }

    /** Leitura válida = presente e dentro da faixa física 0..altura. */
    public boolean valida(Double distanciaCm) {
        return distanciaCm != null && !distanciaCm.isNaN()
                && distanciaCm >= 0 && distanciaCm <= alturaCm;
    }

    /** Distância (cm) -> nível ocupado (%). Só chame com leitura válida. */
    public double pct(double distanciaCm) {
        return (alturaCm - distanciaCm) / alturaCm * 100.0;
    }

    /** Queda grande vinda de um nível alto = operador esvaziou o reservatório (evento normal). */
    public boolean esvaziamento(double pctAnterior, double pctAtual) {
        return pctAnterior >= 85 && (pctAtual - pctAnterior) <= -50;
    }

    public List<Leitura> validas(List<Leitura> leituras) {
        List<Leitura> out = new ArrayList<>();
        for (Leitura l : leituras) {
            if (valida(l.getDistanciaCm())) out.add(l);
        }
        return out;
    }

    /** Devolve só as leituras desde o último esvaziamento (o ciclo de enchimento atual). */
    public List<Leitura> cicloAtual(List<Leitura> validasOrdenadas) {
        List<Leitura> ciclo = new ArrayList<>();
        for (Leitura l : validasOrdenadas) {
            if (!ciclo.isEmpty()) {
                double anterior = pct(ciclo.get(ciclo.size() - 1).getDistanciaCm());
                if (esvaziamento(anterior, pct(l.getDistanciaCm()))) ciclo.clear();
            }
            ciclo.add(l);
        }
        return ciclo;
    }

    /** Divide as leituras válidas em todos os ciclos de enchimento (separados por esvaziamentos). */
    public List<List<Leitura>> ciclos(List<Leitura> validasOrdenadas) {
        List<List<Leitura>> res = new ArrayList<>();
        List<Leitura> atual = new ArrayList<>();
        for (Leitura l : validasOrdenadas) {
            if (!atual.isEmpty()) {
                double anterior = pct(atual.get(atual.size() - 1).getDistanciaCm());
                if (esvaziamento(anterior, pct(l.getDistanciaCm()))) {
                    res.add(atual);
                    atual = new ArrayList<>();
                }
            }
            atual.add(l);
        }
        if (!atual.isEmpty()) res.add(atual);
        return res;
    }

    public static double arred(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}

package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.dto.Dtos;
import br.com.metaltech.monitoramento.model.Leitura;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Estatística descritiva completa: média, mediana, moda, desvio, quartis, histograma,
 * boxplot (outliers pelo IQR) e taxa de enchimento por ciclo com critério de alerta.
 */
@Service
public class DescritivaService {

    private static final int MIN_AMOSTRAS_CICLO = 30;
    private static final int MAX_OUTLIERS_LISTADOS = 200;

    private final Reservatorio reservatorio;
    private final EstatisticaService estatistica;
    private final double fatorMediana;

    public DescritivaService(Reservatorio reservatorio,
                             EstatisticaService estatistica,
                             @Value("${metaltech.enchimento.fator-mediana:1.5}") double fatorMediana) {
        this.reservatorio = reservatorio;
        this.estatistica = estatistica;
        this.fatorMediana = fatorMediana;
    }

    public Dtos.DescritivaDTO descritiva(List<Leitura> leituras, int intervaloMin, int faixaPct) {
        List<Leitura> validas = reservatorio.validas(leituras);
        double[] niveis = validas.stream()
                .mapToDouble(l -> reservatorio.pct(l.getDistanciaCm()))
                .toArray();

        // contagem de peças por tipo em cada intervalo de tempo
        List<Dtos.PontoSerieDTO> pontos = estatistica.serie(leituras, intervaloMin, 1);
        double[] metalicas = pontos.stream().mapToDouble(Dtos.PontoSerieDTO::metalicas).toArray();
        double[] naoMetalicas = pontos.stream().mapToDouble(Dtos.PontoSerieDTO::naoMetalicas).toArray();

        return new Dtos.DescritivaDTO(
                intervaloMin,
                basica(niveis, true),
                basica(metalicas, false),
                basica(naoMetalicas, false),
                histograma(niveis, faixaPct),
                boxplot(niveis),
                enchimento(validas));
    }

    /** Medidas de tendência central e dispersão. Para o nível, a moda usa valores arredondados a 1 p.p. */
    public Dtos.EstatisticaBasicaDTO basica(double[] v, boolean arredondarModa) {
        if (v.length == 0) {
            return new Dtos.EstatisticaBasicaDTO(0, null, null, null, null, null, null, null, null, null);
        }
        DescriptiveStatistics ds = new DescriptiveStatistics(v);
        double q1 = ds.getPercentile(25);
        double q3 = ds.getPercentile(75);
        return new Dtos.EstatisticaBasicaDTO(
                v.length,
                Reservatorio.arred(ds.getMean()),
                Reservatorio.arred(ds.getPercentile(50)),
                moda(v, arredondarModa),
                Reservatorio.arred(ds.getStandardDeviation()),
                Reservatorio.arred(ds.getMin()),
                Reservatorio.arred(q1),
                Reservatorio.arred(q3),
                Reservatorio.arred(q3 - q1),
                Reservatorio.arred(ds.getMax()));
    }

    private Double moda(double[] v, boolean arredondar) {
        Map<Double, Integer> freq = new TreeMap<>();
        for (double x : v) {
            double chave = arredondar ? Math.round(x) : x;
            freq.merge(chave, 1, Integer::sum);
        }
        double melhor = 0;
        int max = 0;
        for (Map.Entry<Double, Integer> e : freq.entrySet()) {
            if (e.getValue() > max) { // estritamente maior: em empate fica o menor valor
                max = e.getValue();
                melhor = e.getKey();
            }
        }
        return max > 1 ? Reservatorio.arred(melhor) : null;
    }

    /** Histograma do nível em faixas de {@code faixa} pontos percentuais (0 a 100). */
    public List<Dtos.FaixaHistogramaDTO> histograma(double[] v, int faixa) {
        int f = Math.max(1, faixa);
        int bins = (int) Math.ceil(100.0 / f);
        int[] cont = new int[bins];
        for (double x : v) {
            int idx = (int) Math.min(bins - 1, Math.max(0, Math.floor(x / f)));
            cont[idx]++;
        }
        List<Dtos.FaixaHistogramaDTO> out = new ArrayList<>();
        for (int i = 0; i < bins; i++) {
            out.add(new Dtos.FaixaHistogramaDTO(i * (double) f, Math.min(100.0, (i + 1) * (double) f), cont[i]));
        }
        return out;
    }

    /** Boxplot com regra de Tukey: outlier = abaixo de Q1 - 1,5 x IQR ou acima de Q3 + 1,5 x IQR. */
    public Dtos.BoxplotDTO boxplot(double[] v) {
        if (v.length == 0) {
            return new Dtos.BoxplotDTO(null, null, null, null, null, null, null, 0, List.of());
        }
        DescriptiveStatistics ds = new DescriptiveStatistics(v);
        double q1 = ds.getPercentile(25);
        double q3 = ds.getPercentile(75);
        double iqr = q3 - q1;
        double limInf = q1 - 1.5 * iqr;
        double limSup = q3 + 1.5 * iqr;

        double bigodeInf = Double.POSITIVE_INFINITY;
        double bigodeSup = Double.NEGATIVE_INFINITY;
        List<Double> outliers = new ArrayList<>();
        int total = 0;
        for (double x : v) {
            if (x < limInf || x > limSup) {
                total++;
                if (outliers.size() < MAX_OUTLIERS_LISTADOS) outliers.add(Reservatorio.arred(x));
            } else {
                bigodeInf = Math.min(bigodeInf, x);
                bigodeSup = Math.max(bigodeSup, x);
            }
        }
        return new Dtos.BoxplotDTO(
                Reservatorio.arred(bigodeInf), Reservatorio.arred(q1),
                Reservatorio.arred(ds.getPercentile(50)), Reservatorio.arred(q3),
                Reservatorio.arred(bigodeSup),
                Reservatorio.arred(limInf), Reservatorio.arred(limSup),
                total, outliers);
    }

    /**
     * Taxa de enchimento (p.p. por minuto) de cada ciclo, por regressão linear.
     * Alerta quando a taxa do ciclo > fator x mediana das taxas (robusto: a mediana não é
     * puxada pelos próprios ciclos anômalos, o que acontece com média + desvio).
     */
    private Dtos.EnchimentoDTO enchimento(List<Leitura> validas) {
        List<CicloTmp> tmp = new ArrayList<>();
        for (List<Leitura> ciclo : reservatorio.ciclos(validas)) {
            if (ciclo.size() < MIN_AMOSTRAS_CICLO) continue;
            long t0 = ciclo.get(0).getTimestamp().toEpochSecond(ZoneOffset.UTC);
            SimpleRegression reg = new SimpleRegression();
            for (Leitura l : ciclo) {
                reg.addData(l.getTimestamp().toEpochSecond(ZoneOffset.UTC) - t0,
                        reservatorio.pct(l.getDistanciaCm()));
            }
            double taxa = reg.getSlope() * 60.0;
            if (Double.isNaN(taxa)) continue;
            LocalDateTime ini = ciclo.get(0).getTimestamp();
            LocalDateTime fim = ciclo.get(ciclo.size() - 1).getTimestamp();
            double dur = (fim.toEpochSecond(ZoneOffset.UTC) - t0) / 60.0;
            tmp.add(new CicloTmp(ini, fim, dur, taxa));
        }

        String criterio = "Alerta quando a taxa do ciclo > " + fatorMediana + " x mediana das taxas dos ciclos";
        if (tmp.isEmpty()) {
            return new Dtos.EnchimentoDTO(null, null, criterio, List.of());
        }

        double[] taxas = tmp.stream().mapToDouble(CicloTmp::taxa).toArray();
        double mediana = new DescriptiveStatistics(taxas).getPercentile(50);
        Double limite = tmp.size() >= 3 ? mediana * fatorMediana : null;

        List<Dtos.CicloEnchimentoDTO> ciclos = new ArrayList<>();
        for (CicloTmp c : tmp) {
            ciclos.add(new Dtos.CicloEnchimentoDTO(c.inicio(), c.fim(),
                    Reservatorio.arred(c.duracaoMin()), Reservatorio.arred(c.taxa()),
                    limite != null && c.taxa() > limite));
        }
        return new Dtos.EnchimentoDTO(Reservatorio.arred(mediana),
                limite == null ? null : Reservatorio.arred(limite), criterio, ciclos);
    }

    private record CicloTmp(LocalDateTime inicio, LocalDateTime fim, double duracaoMin, double taxa) {}
}

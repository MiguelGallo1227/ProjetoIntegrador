package br.com.metaltech.monitoramento.service;

import br.com.metaltech.monitoramento.model.Leitura;
import br.com.metaltech.monitoramento.repository.LeituraRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Simula a esteira enquanto o hardware real não existe.
 * Injeta falhas de propósito: leitura ausente, leitura impossível, salto, conflito
 * indutivo+capacitivo, esteira parada (40 leituras), sensor travado (25 leituras) e um trecho de
 * enchimento acelerado (250 leituras com fluxo de peças ~2,5x maior).
 */
@Service
public class SimuladorService {

    private final LeituraRepository repo;
    private final Reservatorio reservatorio;

    public SimuladorService(LeituraRepository repo, Reservatorio reservatorio) {
        this.repo = repo;
        this.reservatorio = reservatorio;
    }

    @Transactional
    public int gerarESalvar(int quantidade, long seed, int intervaloSeg) {
        LocalDateTime inicio = LocalDateTime.now()
                .minusSeconds((long) quantidade * intervaloSeg)
                .truncatedTo(ChronoUnit.SECONDS);
        List<Leitura> lista = gerarLista(quantidade, seed, intervaloSeg, inicio);
        repo.deleteAll();
        repo.saveAll(lista);
        return lista.size();
    }

    /** Função pura (sem banco): facilita testes e o uso no relatório. Use n >= 200. */
    public List<Leitura> gerarLista(int n, long seed, int intervaloSeg, LocalDateTime inicio) {
        Random rnd = new Random(seed); // mesma seed = mesma base (reprodutível)
        double altura = reservatorio.getAlturaCm();
        double preenchido = 0.5;   // altura (cm) ocupada por peças
        int contador = 0;

        int paradaIni = (int) (n * 0.30), paradaFim = paradaIni + 40;
        int travadoIni = (int) (n * 0.60), travadoFim = travadoIni + 25;
        int enchIni = (int) (n * 0.75), enchFim = enchIni + 250; // fluxo de peças muito maior
        double valorTravado = 0;

        List<Leitura> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            // operador esvazia o reservatório ao chegar em 95%
            if (preenchido / altura * 100.0 >= 95) preenchido = 0.5;

            boolean parada = i >= paradaIni && i < paradaFim;
            boolean conflito = !parada && rnd.nextDouble() < 0.01;
            double probPeca = (i >= enchIni && i < enchFim) ? 0.90 : 0.35;
            boolean peca = conflito || (!parada && rnd.nextDouble() < probPeca);
            boolean metal = rnd.nextDouble() < 0.60;

            if (peca) {
                preenchido += 0.2 + 0.1 * rnd.nextDouble();
                contador++;
            }

            Double distancia = round2(altura - preenchido + rnd.nextGaussian() * 0.05);

            if (i >= travadoIni && i < travadoFim) {
                if (i == travadoIni) valorTravado = distancia;
                distancia = valorTravado; // sensor congelado
            } else {
                double r = rnd.nextDouble();
                if (r < 0.005) {
                    distancia = null; // leitura ausente
                } else if (r < 0.010) {
                    // pico: ou valor impossível, ou salto extremo dentro da faixa
                    distancia = rnd.nextBoolean() ? -1.0 : (distancia < altura / 2 ? altura - 1 : 1.0);
                }
            }

            boolean indutivo = conflito || (peca && metal);
            boolean capacitivo = conflito || (peca && !metal);
            out.add(new Leitura(inicio.plusSeconds((long) i * intervaloSeg),
                    distancia, indutivo, capacitivo, contador));
        }
        return out;
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
